<template>
    <div>
        <div>
            <component v-bind:is="actual_page"></component>
        </div>
    </div>
</template>

<script>

   
    export default {
        components: {
        },
        data() {
            return {
                actual_page: 'home'
            }
        },
        methods: {
            pageAct(nom_page) {
                this.actual_page = nom_page;
                
                
            },
            asigPageAct() {
                
                     var pathname = window.location.href;
                    var arrCurrentPage = pathname.split("template/");
                    if(arrCurrentPage.length==2)
                    {
                        if(arrCurrentPage[1].length>0)
                        {
                          this.pageAct(arrCurrentPage[1]);
                          var title =arrCurrentPage[1].replace(/-vue/g, '');
                          $('title').html(title);
                        }
                    }
                
                
            },
            inArray(busq, arr_busq) {
                for (var i = 0; i < arr_busq.length; i++) {
                    if (this.arr_busq[i] == busq) {
                        return true;
                    }
                }
                return false;
            },
        },
        mounted() {
             
            this.asigPageAct();
        },
        computed: {
        },
        created() {
        }
    }

</script>