<template>
<div>

<div class="row">
<!--Frm Edit Users-->
<div class="col-md-12">
    <div id="dvFrmCreatedAndEdit" class="div-modal box box-primary box-solid">
       <div class="box-header with-border">   
           <h5 class="box-title" ><div id="dvTitleFrmCreatedAndEdit"></div></h5>
           <div class="box-tools pull-right">
               <button class="btn btn-box-tool" data-widget-modal="remove" type="button" title="Close"><i class="fa fa-times"></i> </button>
           </div>
       </div>
       <div class="box-body">
           <form method="POST" id="frmpayments" class="form-horizontal" onsubmit="return false;">
               <div class="box-body">
                   <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Nro Factura</label><label class="requiredfield">*</label>
                               <div class="input-group">
                                <div class="input-group-prepend"><span class="input-group-text-form-b"><i class=" fas fa-search"></i></span></div>
                                <input type="text" id="TBUStxtBillNum" style="text-transform: uppercase" name="TBUStxtBillNum" maxlength="60" class="form-control">
                                <input type="hidden" id="txtBillNum" style="text-transform: uppercase" name="txtBillNum">

                                 </div>
                            </div>
                        </div>
                    </div>
                   
               <div class="box-footer">
                   <div class="row">
                        <div class="col-md-12">
                           <div class="button-group">
                               <button type="button" class="btn btn-info waves-effect waves-light" id="btnSave" name="btnSave"> <i class="fa fa-save"></i>Guardar</button>
                               <button type="reset" class="btn waves-effect waves-light btn-light"> <i class="fa fa-eraser"></i>Limpiar</button>
                               <button type="button" class="btn waves-effect waves-light btn-danger" data-widget-modal="remove"> <i class="fas fa-window-close"></i>Cancelar</button>
                           </div>    
                       </div>    
                   </div> 
               </div>
               </div>
           </form>
          
       </div>  
   </div>
    
</div>
</div>
</div>
</template>
<script type="text/javascript">
import DataTable from './dataTable.vue'
import VdtnetTable from 'vue-datatables-net'

     export default{
           components: {DataTable,VdtnetTable},
       
       
        data() {
            return {
            }
        },
        methods:{
            

        },
         
        mounted() {
             
             var objInputFrm = {      
                txtNroConsult: 'number', 
                txtBillValue: 'number' 
            };
            checkFieldInputFrm(objInputFrm); 
            
            
        var objAutoComplete = new Array(); 

        

        objAutoComplete[0]={
            input:'txtPersonConsult',
            model:'People',
            route:'Settings\\Administration'
        };
       
       objAutoComplete[1]={
            input:'txtPerson',
            model:'People',
            route:'Settings\\Administration'
        };
        objAutoComplete[2]={
            input:'txtBillConsult',
            model:'Bills',
            route:'Settings\\Administration',
            length:1
        };
        objAutoComplete[3]={
            input:'txtBillNum',
            model:'Bills',
            route:'Settings\\Administration',
            length:1
        };
            textFinder(objAutoComplete); 
        },
         created(){
    }
    }
</script>