<script>
    
    export default{
        components:{
        },
       
        data() {
            return {
                optionsConsult: {
                    ajax: {
                      url:'/administration/payments',
                      data: function (d) 
                      {
                            $('#frmConsult').find(':input').each(function () 
                            {
                                var element = this;
                                if (element.id != null) {
                                     d[element.id] = getDataFrmTb(element);
                                }
                            });
                       }
                    },
                    autoWidth: true,
                    responsive: false,
                    lengthMenu: [[15, 25, 50, 100],[15, 25, 50,100]],
                    processing: true,
                    searching: false,
                    destroy: true,
                    serverSide: true,
                     language: {
                                zeroRecords: "",
                                url: "/assets/plugins/dataTables/langs/Spanish.json",
                             }
                  },
                  
                  fieldsConsult:
                  {
                    id:{label: 'Nro Pago',name: 'id', sortable: false},
                    bill_num:{label: 'Nro Factura',name: 'bill_num', sortable: false},
                    name:{label: 'Cliente',name:'name', sortable: false},
                    created_at:{label: 'Fecha Pago',name:'created_at', sortable: false},
                    bill_value:{label: 'Valor',name:'bill_value', sortable: false},
                    buttons: {
                        sortable: false,
                        label: '________',
                        render: (data) => {
                            
                             var  obj=b64ToUtf8(data);
                             var jsonObj = JSON.parse(obj);
                             var str='';
                           
                            //str=str+'<span data-action="edit" class="btn-tb btn-warning btn-sm" title="Edit"><i class="fa fa-edit"></i></span>&nbsp;';
                           
                           // str=str+'<span data-action="delete" class="btn-tb btn-googleplus btn-sm" title="Borrar factura"><i class="fa fa-times"></i></span>';
                        
                          return str;
                        }
                      }
                  }
            }
        },
        watch: {
        },
        mounted() {
            
        }
    }
</script>