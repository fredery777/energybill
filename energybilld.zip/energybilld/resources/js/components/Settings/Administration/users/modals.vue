<template>
<div>

<div class="row">
<!--Frm Edit Users-->
<div class="col-md-12">
    <div id="dvFrmCreatedAndEdit" class="div-modal box box-primary box-solid">
       <div class="box-header with-border">   
           <h5 class="box-title" ><div id="dvTitleFrmCreatedAndEdit"></div></h5>
           <div class="box-tools pull-right">
               <button class="btn btn-box-tool" data-widget-modal="remove" type="button" title="Close"><i class="fa fa-times"></i> </button>
           </div>
       </div>
       <div class="box-body">
           <form method="POST" id="frmUsers" class="form-horizontal" onsubmit="return false;">
               <div class="box-body">
                   <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>First name</label><label class="requiredfield">*</label>
                                <input type="text" id="txtUserName" name="txtUserName" maxlength="100" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Last name</label>
                                <input type="text" id="txtUserSurname" name="txtUserSurname" maxlength="100" class="form-control">
                            </div>
                        </div>
                    </div>
                   <div class="row">
                       <div class="col-md-6" id="dvEmailConf">
                            <div class="form-group">
                                <label>Email</label><label class="requiredfield">*</label>
                                <input type="email" id="txtUserEmail" name="txtUserEmail" maxlength="560" class="form-control">
                            </div>
                        </div>
                       <div class="col-md-6" id="dvUserEmailConf">
                            <div class="form-group">
                                <label>Confirm email</label><label class="requiredfield">*</label>
                                <input type="email" id="txtUserEmailConf" name="txtUserEmailConf" maxlength="560" class="form-control">
                            </div>
                        </div>
                    </div>
                   <div class="row">
                        <div class="col-md-12">
                            <div class="g-recaptcha" data-sitekey="6Le-Ab8UAAAAAAd--Gf6gap_oTVhBszX2HbQLzCF"></div>
                        </div>
                    </div>
               <div class="box-footer">
                   <div class="row">
                        <div class="col-md-12">
                           <div class="button-group">
                               <button type="button" class="btn btn-info waves-effect waves-light" id="btnSave" name="btnSave"> <i class="fa fa-save"></i>Save</button>
                               <button type="reset" class="btn waves-effect waves-light btn-light"> <i class="fa fa-eraser"></i>Clean</button>
                               <button type="button" class="btn waves-effect waves-light btn-danger" data-widget-modal="remove"> <i class="fas fa-window-close"></i>Cancel</button>
                           </div>    
                       </div>    
                   </div> 
               </div>
               </div>
           </form>
          
       </div>  
   </div>
    
</div>
</div>
</div>
</template>
<script type="text/javascript">
import DataTable from './dataTable.vue'
import VdtnetTable from 'vue-datatables-net'

     export default{
           components: {DataTable,VdtnetTable},
       
       
        data() {
            return {
            }
        },
        methods:{
            

        },
         
        mounted() {
             
             var objInputFrm = {      
                txtUserCodConsult: 'number' 
            };
            checkFieldInputFrm(objInputFrm); 
            
        },
         created(){
    }
    }
</script>