<template>
    <div>
        <table class="table table-striped table-bordered nowrap w-100 dataTable no-footer" id="tbActionsPages" style="padding-top: 20px;">
            <thead class="bg-inverse text-white">
               <tr>
                <th class="text-center">&nbsp;&nbsp;</th>
                <th class="text-left">Nombre&nbsp;De&nbsp;Página</th>
                <th class="text-center" v-for="action_header in actionsData.arr_action_header">
                    {{ action_header.action_name }}
                </th>
                </tr>
            </thead>
            <tbody>
            <tr v-for="pages in actionsData.arr_pages" :id="'trPag_'+pages.id">
                <td class="text-center" >
                   <a v-if="pages.arr_actions_optional.length==0">&nbsp;</a>
                   <a v-else  href="javascript:void(0);"><i class="fa fa-plus" :id="'showDet_'+pages.id" data-checked="false" data-created="false" @click="showDetailActionsPage(pages.id,pages.page_name, pages.arr_actions_optional)"></i></a>
                </td>
                <td class="text-nowrap"> {{ pages.page_name }}</td>
                <td class="text-center mytooltip" v-for="actions_not_optional in pages.arr_actions_not_optional">
                    <input v-if="actions_not_optional.action_id==0" @click="checkAllActions($event,'actions_'+actions_not_optional.page_id)" :class="'actions_'+pages.id" type="checkbox"  name="chkAllActions" :id="'chkActions'+pages.id+'_'+actions_not_optional.action_id" :value="pages.id"   style="cursor:pointer"  />
                    
                    <input v-else type="checkbox" :checked="actions_not_optional.checked" :class="'actions_'+pages.id"  name="chkActions"  :id="'chkActions'+pages.id+'_'+actions_not_optional.action_id" :title="'Acción:'+actions_not_optional.action_name" :value="pages.id+'-'+actions_not_optional.action_id" style="cursor:pointer" />
                    <span v-if="actions_not_optional.action_id==0" class="tooltip-content3">Activar/Desactivar los permisos.</span><span v-else class="tooltip-content3">Acción:{{actions_not_optional.action_name}}.</span>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</template>
<script>
    
    export default{
             props: [
              'actionsData'
              ],
        components:{
            
        },
        data() {
            return {
            }
        },
        methods:{
         checkAllActions(event,className)
           {
              $('.'+className).prop('checked',event.target.checked);
           },
           showDetailActionsPage(pageId,pageName,arrActionsOptional)
           {
              var checked=$("#showDet_"+pageId).data("checked");
              var created=$("#showDet_"+pageId).data("created");
              var index=parseInt($("#trPag_"+pageId).index())+1;
               var html='';
               
               if(checked)
               {
                   $("#showDet_"+pageId).data("checked",false);
                   $("#showDet_"+pageId).removeClass('fa fa-minus').addClass('fa fa-plus');
               }
               else
               {
                    $("#showDet_"+pageId).data("checked",true);
                     $("#showDet_"+pageId).removeClass('fa fa-plus').addClass('fa fa-minus');
               }
                   
                   
               if(!created)
               {
                    
                    if(existObj('trPagDet_'+pageId))
                    {
                           $( "#trPagDet_"+pageId ).remove();
                    }
                    
                  $("#showDet_"+pageId).data( "created",true);
                   html='<tr id="trPagDet_'+pageId+'">';
                   html=html+'<td colspan="13">';
                   html=html+'<div class="row"><div class="col-md-12">';
                   html=html+'<div class="ribbon-wrapper card">';
                   html=html+'<div class="ribbon ribbon-bookmark  ribbon-default">Permisos Específicos Página:'+pageName+'</div>';
                  
                   html=html+'<div class="row">';
                   arrActionsOptional.forEach(function(objActionsOptional){
                       
                       html=html+'<div class="col-lg-3 col-md-4 col-sm-3 col-xs-12">';
                       html=html+'<div class="custom-control custom-checkbox">';
                       html=html+'<input type="checkbox" class="custom-control-input det_checked_'+objActionsOptional.checked+'" style="cursor:pointer" name="chkActions" id="chkActions'+objActionsOptional.page_id+'_'+objActionsOptional.action_id+'" value="'+objActionsOptional.page_id+'-'+objActionsOptional.action_id+'" />';
                       html=html+'<label style="cursor:pointer" class="custom-control-label" for="chkActions'+objActionsOptional.page_id+'_'+objActionsOptional.action_id+'">'+objActionsOptional.action_name+'</label>';
                       html=html+'</div>';
                       html=html+'</div>';
               
                    });
                   html=html+'</div></div></div></div>';
                    html=html+'</td>';
                   html=html+'</tr>';
                   $('#tbActionsPages tbody tr:nth-child(' + index + ')').after(html);
                   $('.det_checked_true').prop('checked',true);

               }
               if(checked&&created)
               {
                  hideDiv('trPagDet_'+pageId);
               }
               else
               {
                 showDiv('trPagDet_'+pageId);
               }

           }
        },
        watch: {
        },
        mounted() {
           
        }
    }

</script>