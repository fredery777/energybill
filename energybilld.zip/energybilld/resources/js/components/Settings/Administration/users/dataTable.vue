<script>
    
    export default{
        components:{
        },
       
        data() {
            return {
                optionsConsult: {
                    ajax: {
                      url:'/administration/users',
                      data: function (d) 
                      {
                            $('#frmConsult').find(':input').each(function () 
                            {
                                var element = this;
                                if (element.id != null) {
                                     d[element.id] = getDataFrmTb(element);
                                }
                            });
                       }
                    },
                    autoWidth: true,
                    responsive: false,
                    lengthMenu: [[15, 25, 50, 100],[15, 25, 50,100]],
                    processing: true,
                    searching: false,
                    destroy: true,
                    serverSide: true
                  },
                  
                  fieldsConsult:
                  {
                    id:{label: 'Cod',name: 'id', sortable: false},
                    firstname:{label: 'First name',name:'firstname', sortable: false},
                    lastname:{label: 'Last name',name:'lastname', sortable: false},
                    email:{label: 'Email',name:'email', sortable: false},
                    created_at:{label: 'Created at',name:'created_at', sortable: false},
                    buttons: {
                        sortable: false,
                        label: '________',
                        render: (data) => {
                             var str='';
     
                            str=str+'<span data-action="edit" class="btn-tb btn-warning btn-sm" title="Edit"><i class="fa fa-edit"></i></span>&nbsp;';
                            str=str+'<span data-action="delete" class="btn-tb btn-googleplus btn-sm" title="Delete Perfil"><i class="fa fa-times"></i></span>';
                             
                          return str;
                        }
                      }
                  }
            }
        },
        watch: {
        },
        mounted() {
            
        }
    }
</script>