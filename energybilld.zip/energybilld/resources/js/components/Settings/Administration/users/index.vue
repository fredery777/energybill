<template>
    
    <div>
<!--*********** Start modals ************ -->
<modals ref="modals"></modals>
<!-- *********** End modals *********** -->

<!--Frm Consult-->
<form class="form pt-3" id="frmConsult" name="frmConsult" onsubmit="return false;">
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label>Cod</label>
            <input type="text" id="txtUserCodConsult" style="text-transform: uppercase" name="txtUserCodConsult" maxlength="60" class="form-control">
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label>Email</label>
            <input type="text" id="txtUserMailConsult" name="txtUserMailConsult" maxlength="200" class="form-control">
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label>First name</label>
            <input type="text" id="txtUserNameConsult" style="text-transform: uppercase" name="txtUserNameConsult" maxlength="60" class="form-control">
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label>Last name</label>
            <input type="text" id="txtUserSurnameConsult" style="text-transform: uppercase" name="txtUserSurnameConsult" maxlength="60" class="form-control">
        </div>
    </div>
</div>
<hr>
<div class="row">
 <div class="col-md-12">
    <div class="button-group">
        <button type="button" class="btn btn-info waves-effect waves-light" id="btnBusq" @click="consult()"> <i class="fa fa-search"></i>Consult</button>
        <button type="button" class="btn waves-effect waves-light btn-secondary"  id="btnFrmStorageUser" @click="frmStorage()"> <i class="fa fa-plus-square"></i>New</button>
        <button type="reset" class="btn waves-effect waves-light btn-light"> <i class="fa fa-eraser"></i>Clean</button>
        <button type="button" class="btn waves-effect waves-light btn-success"  id="btnExport" @click="exportExcel()"> <i class="fas fa-file-excel" ></i>Export xls</button>
    </div>    
</div>    
</div>    
</form>
    <!--Table Consult-->   
    <div class="box_table">
        <!-- Using the VdtnetTable component -->
        <vdtnet-table 
            ref="tableConsult"
            :fields="fieldsConsult"
            :opts="optionsConsult"
            @delete="deleteFrm"
            @edit="editFrm"
            />

    </div>
<!--End Frm Consult-->

</div>
</template>
<script type="text/javascript">
import modals from './modals.vue'
import DataTable from './dataTable.vue'
import VdtnetTable from 'vue-datatables-net'

export default
{
    components: {DataTable,VdtnetTable,modals},
    data(){
        return {
                 optionsConsult:DataTable.data().optionsConsult,
                 fieldsConsult:DataTable.data().fieldsConsult
            }

    },
    methods:{
        consult(){
            const table = this.$refs.tableConsult; //table ref
            table.reload();
        },
        frmStorage(){
                grecaptcha.reset();
                $('#btnSave').unbind('click');
                $('#btnSave').html('<i class="fa fa-save"></i>Save');
                $('#dvTitleFrmCreatedAndEdit').html('Create user');
                clearForm('frmUsers');//clean frm
                
                $('#btnSave').click(function ()
                {
                    
                    
                    var objValidate = 
                    {
                        txtUserName: {required: true, name: "First name"},
                        txtUserEmail: {required: true,type:"email", name: "Email"},
                        txtUserEmailConf: {required: true,type:"email", name: "Confirm email"}
                    };
                    
                    if($('#txtUserEmail').val()!=$('#txtUserEmailConf').val())
                        {
                            SweetAlertError('Error', "The Confirmation Email are not similar");
                            return false;
                        }
                       if(!validateEmail($('#txtUserEmail').val()))
                       {
                           SweetAlertError('Error', "The email does not have the format");
                           return false;
                       }
                        if (grecaptcha.getResponse() == '')
                        {
                            // if error I post a message
                             SweetAlertError('Error', "Please verify youare human");
                             return false;
                        }
                    
                    if(validate(objValidate))
                    {
                        requestAjax({
                                type: 'POST',
                                url: '/administration/users',
                                form: 'frmUsers',
                                success: 'User Created',
                                div: 'dvFrmCreatedAndEdit',
                                hide: true,
                                resetForm: true,
                                clickButton: 'btnBusq'
                                });
                    }
                });
                showDiv('dvFrmCreatedAndEdit');
                 showDiv('dvUserEmailConf');
        },
        editFrm(data) {
             grecaptcha.reset();
              hideDiv('dvUserEmailConf');
            $('#btnSave').unbind('click');
            $('#btnSave').html('<i class="fa fa-save"></i>Edit');
            $('#dvTitleFrmCreatedAndEdit').html('Edit User:'+data.firstname+' '+data.lastname);
            clearForm('frmUsers');
            var objRequest = {type: 'GET', url: '/administration/users/' + data.id + '/edit', return:true};
            var jsonRta = requestAjax(objRequest);
            //Assign form values returned from the controller
            assignDataFrm(jsonRta);
            $('#btnSave').click(function () {
                 var objValidate = 
                    {
                        txtUserName: {required: true, name: "First name"},
                        txtUserEmail: {required: true,type:"email", name: "Email"}
                    };
                    if(!validateEmail($('#txtUserEmail').val()))
                       {
                           SweetAlertError('Error', "The email does not have the format");
                           return false;
                       }
                        if (grecaptcha.getResponse() == '')
                        {
                            // if error I post a message
                             SweetAlertError('Error', "Please verify youare human");
                             return false;
                        }
                    if(validate(objValidate))
                    {
                        var objButton = {
                            type: 'PUT',
                            url: '/administration/users/' + data.id,
                            form: 'frmUsers',
                            div: 'dvFrmCreatedAndEdit',
                            hide: true,
                            success: 'User Updated',
                            clickButton: 'btnBusq'
                        };
                     }
                requestAjax(objButton);
            });
           showDiv('dvFrmCreatedAndEdit');

        },
        deleteFrm(data) {
            
            Swal.fire({
                title: 'Sure you want to delete?',
                text: "Delete user "+data.firstname+"!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si',
                cancelButtonText: 'No',
            }).then((result) => 
            {
                if (result.value) {
                   var objButton = {
                        type: 'DELETE',
                        url: '/administration/users/' + data.id,
                        form: 'frmConsult',
                        success: 'User Deleted',
                        clickButton: 'btnBusq'
                    };
                    requestAjax(objButton);
                }
            });
        },
        exportExcel() {
            hideTimeEl('btnExport',3000);
            var jsonData=fieldsFrmToObj('frmConsult');
            $.redirect('/administration/users/exportExcel', jsonData,'GET');
 
        },
    },
    mounted(){
        $('#titlePag').html('Users');//edit title
    },
    created(){
    }

}
</script>