<script>
    
    export default{
        components:{
        },
       
        data() {
            return {
                optionsConsult: {
                    ajax: {
                      url:'/administration/bills',
                      data: function (d) 
                      {
                            $('#frmConsult').find(':input').each(function () 
                            {
                                var element = this;
                                if (element.id != null) {
                                     d[element.id] = getDataFrmTb(element);
                                }
                            });
                       }
                    },
                    autoWidth: true,
                    responsive: false,
                    lengthMenu: [[15, 25, 50, 100],[15, 25, 50,100]],
                    processing: true,
                    searching: false,
                    destroy: true,
                    serverSide: true,
                     language: {
                                zeroRecords: "",
                                url: "/assets/plugins/dataTables/langs/Spanish.json",
                             }
                  },
                  
                  fieldsConsult:
                  {
                    id:{label: 'Nro',name: 'id', sortable: false},
                    name:{label: 'Cliente',name:'name', sortable: false},
                    
                    name_status_bill:{label: 'Estado',name:'name_status_bill', sortable: false},
                    payment_date:{label: 'Fecha De Pago',name:'payment_date', sortable: false},
                    created_at:{label: 'Fecha',name:'created_at', sortable: false},
                    kwh:{label: 'Consumo Kwh',name:'kwh', sortable: false},
                    bill_value:{label: 'Valor',name:'bill_value', sortable: false},
                    buttons: {
                        sortable: false,
                        label: '________',
                        render: (data) => {
                            
                             var  obj=b64ToUtf8(data);
                             var jsonObj = JSON.parse(obj);
                             var str='';
                            if(jsonObj.del_bill)
                            {
                            //str=str+'<span data-action="edit" class="btn-tb btn-warning btn-sm" title="Edit"><i class="fa fa-edit"></i></span>&nbsp;';
                           
                            //str=str+'<span data-action="delete" class="btn-tb btn-googleplus btn-sm" title="Borrar factura"><i class="fa fa-times"></i></span>';
                        }
                          return str;
                        }
                      }
                  }
            }
        },
        watch: {
        },
        mounted() {
            
        }
    }
</script>