<template>
    
    <div>
<!--*********** Start modals ************ -->
<modals ref="modals"></modals>
<!-- *********** End modals *********** -->

<!--Frm Consult-->
<form class="form pt-3" id="frmConsult" name="frmConsult" onsubmit="return false;">
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label>Nro</label>
            <input type="text" id="txtNroConsult" style="text-transform: uppercase" name="txtNroConsult" maxlength="60" class="form-control">
        </div>
    </div>
    <div class="col-md-6">
         <div class="form-group">
        <label for="TBUStxtPersonConsult">Cliente</label>
        <div class="input-group">
            <div class="input-group-prepend"><span class="input-group-text-form-b"><i class=" fas fa-search"></i></span></div>
            <input type="text" id="TBUStxtPersonConsult" style="text-transform: uppercase" name="TBUStxtPersonConsult" maxlength="60" class="form-control">
            <input type="hidden" id="txtPersonConsult" style="text-transform: uppercase" name="txtPersonConsult">
 
        </div>
    </div> 
    </div>
</div>
<div class="row">
   <div class="col-md-6">
        <div class="form-group">
             <label>Fecha Desde</label>
             <input id="txtDateSinceConsult" name="txtDateSinceConsult"  class="form-control time_calendar"  type="text" readonly="true" data-opt="{'singleDatePicker':true,'showDropdowns':true,'minYear':1901,'drops':'up','clear':false}" />
        </div>
   </div>
   <div class="col-md-6">
        <div class="form-group">
             <label>Fecha Hasta</label>
             <input id="txtDateUntilConsult" value="" name="txtDateUntilConsult"  class="form-control time_calendar"  type="text" readonly="true" data-opt="{'singleDatePicker':true,'showDropdowns':true,'minYear':1901,'drops':'up','clear':false}" />
        </div>
   </div>
    
</div> 
<hr>
<div class="row">
 <div class="col-md-12">
    <div class="button-group">
        <button type="button" class="btn btn-info waves-effect waves-light" id="btnBusq" @click="consult()"> <i class="fa fa-search"></i>Consultar</button>
        <button type="button" class="btn waves-effect waves-light btn-secondary"  id="btnFrmStorageUser" @click="frmStorage()"> <i class="fa fa-plus-square"></i>Crear</button>
        <button type="reset" class="btn waves-effect waves-light btn-light"> <i class="fa fa-eraser"></i>Limpiar</button>
    </div>    
</div>    
</div>    
</form>
    <!--Table Consult-->   
    <div class="box_table">
        <!-- Using the VdtnetTable component -->
        <vdtnet-table 
            ref="tableConsult"
            :fields="fieldsConsult"
            :opts="optionsConsult"
            @delete="deleteFrm"
            @edit="editFrm"
            />

    </div>
<!--End Frm Consult-->

</div>
</template>
<script type="text/javascript">
import modals from './modals.vue'
import DataTable from './dataTable.vue'
import VdtnetTable from 'vue-datatables-net'

export default
{
    components: {DataTable,VdtnetTable,modals},
    data(){
        return {
                 optionsConsult:DataTable.data().optionsConsult,
                 fieldsConsult:DataTable.data().fieldsConsult
            }

    },
    methods:{
        consult(){
            const table = this.$refs.tableConsult; //table ref
            table.reload();
        },
        frmStorage(){
               
                $('#btnSave').unbind('click');
                $('#btnSave').html('<i class="fa fa-save"></i>Guardar');
                $('#dvTitleFrmCreatedAndEdit').html('Crear Factura');
                clearForm('frmbills');//clean frm
                
                $('#btnSave').click(function ()
                {
                    
                    
                    var objValidate = 
                    {
                        txtBillValue: {required: true, name: "Valor"},
                        txtPerson: {required: true, name: "Persona"},
                        txtPaymentDate: {required: true, name: "Fecha de pago"},
                        txtKwhValue: {required: true, name: "Total de Kwh"}
                    };
                    
                   
                       
                    
                    if(validate(objValidate))
                    {
                        requestAjax({
                                type: 'POST',
                                url: '/administration/bills',
                                form: 'frmbills',
                                success: 'Factura creada',
                                div: 'dvFrmCreatedAndEdit',
                                hide: true,
                                resetForm: true,
                                clickButton: 'btnBusq'
                                });
                    }
                });
                showDiv('dvFrmCreatedAndEdit');
        },
        editFrm(data) {
            
              hideDiv('dvUserEmailConf');
            $('#btnSave').unbind('click');
            $('#btnSave').html('<i class="fa fa-save"></i>Editar');
            $('#dvTitleFrmCreatedAndEdit').html('Editar Factura:'+data.firstname+' '+data.lastname);
            clearForm('frmbills');
            var objRequest = {type: 'GET', url: '/administration/bills/' + data.id + '/edit', return:true};
            var jsonRta = requestAjax(objRequest);
            //Assign form values returned from the controller
            assignDataFrm(jsonRta);
            $('#btnSave').click(function () {
               var objValidate = 
                    {
                        txtBillValue: {required: true, name: "Valor"},
                        txtPerson: {required: true, name: "Persona"},
                        txtPaymentDate: {required: true, name: "Fecha de pago"},
                          txtKwhValue: {required: true, name: "Total de Kwh"}
                    };
                   
                        
                    if(validate(objValidate))
                    {
                        var objButton = {
                            type: 'PUT',
                            url: '/administration/bills/' + data.id,
                            form: 'frmbills',
                            div: 'dvFrmCreatedAndEdit',
                            hide: true,
                            success: 'Factura Actualizada',
                            clickButton: 'btnBusq'
                        };
                     }
                requestAjax(objButton);
            });
           showDiv('dvFrmCreatedAndEdit');

        },
        deleteFrm(data) {
            
            Swal.fire({
                title: 'Seguro dea borrar la factura?',
                text: "Borrar factura nro "+data.id+"!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si',
                cancelButtonText: 'No',
            }).then((result) => 
            {
                if (result.value) {
                   var objButton = {
                        type: 'DELETE',
                        url: '/administration/bills/' + data.id,
                        form: 'frmConsult',
                        success: 'Factura eliminada',
                        clickButton: 'btnBusq'
                    };
                    requestAjax(objButton);
                }
            });
        }
        
    },
    mounted(){
        $('#titlePag').html('Facturas');//edit title
        timeCalendar();
    },
    created(){
    }

}
</script>