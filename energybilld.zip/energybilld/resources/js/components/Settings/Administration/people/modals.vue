<template>
<div>

<div class="row">
<!--Frm Edit People-->
<div class="col-md-12">
    <div id="dvFrmCreatedAndEdit" class="div-modal box box-primary box-solid">
       <div class="box-header with-border">   
           <h5 class="box-title" ><div id="dvTitleFrmCreatedAndEdit"></div></h5>
           <div class="box-tools pull-right">
               <button class="btn btn-box-tool" data-widget-modal="remove" type="button" title="Cerrar"><i class="fa fa-times"></i> </button>
           </div>
       </div>
       <div class="box-body">
           <form method="POST" id="frmPeople" class="form-horizontal" onsubmit="return false;">
                <div class="box-body">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs customtab2" role="tablist">
                    <li class="nav-item"> <a class="nav-link active" id="navPersonData" data-toggle="tab" href="#personData" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down"></span>Información&nbsp;General </a> </li>
                </ul> 

                    <!-- Tab panes -->
                    <div class="tab-content">
                        
                        <div class="tab-pane active p-3" id="personData" role="tabpanel">
                            <div class="">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Tipo</label><span class="requiredfield">*</span>
                                               <select class="form-control" id="optPersonType" name="optPersonType" @change="showFieldPersonType" >
                                                    <option v-for="(index,key) in jsonSelect.arr_people_types" :value="key">{{index}}</option>
                                              </select>                            
                                         </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Tipo Identificación</label><span class="requiredfield">*</span>
                                               <select class="form-control" id="optIdentificationType" name="optIdentificationType" @change="constrolIdenTypePerson">
                                            </select>                           
                                         </div>
                                    </div>
                               </div>
                               <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Nro Identificación</label><span class="requiredfield">*</span>
                                             <input type="text" id="txtIdentificationNumber" style="text-transform: uppercase" name="txtIdentificationNumber" maxlength="16" class="form-control">

                                         </div>
                                    </div>
                                    <div class="col-md-6 company-data">
                                        <div class="form-group">
                                            <label>Dígito Verificación</label>
                                            <h4 class="card-title "><div id="dvVerificationDigit"></div></h4>                          
                                         </div>
                                    </div>
                               </div>
                               <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Primer Nombre</label><span class="requiredfield">*</span>
                                           <input type="text" id="txtFirstName" style="text-transform: uppercase" name="txtFirstName" maxlength="60" class="form-control">
                                         </div>
                                    </div>
                                    <div class="col-md-6 person-data">
                                        <div class="form-group">
                                            <label>Segundo Nombre</label>
                                           <input type="text" id="txtSecondName" style="text-transform: uppercase" name="txtSecondName" maxlength="60" class="form-control input-person-data"/>
                                         </div>
                                    </div>
                               </div>
                                 <div class="row person-data">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Primer Apellido</label><span class="requiredfield">*</span>
                                            <input type="text" id="txtFirstLastName" style="text-transform: uppercase" name="txtFirstLastName" maxlength="50" class="form-control input-person-data"/>

                                         </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Segundo Apellido</label>
                                            <input type="text" id="txtSecondLastName" style="text-transform: uppercase" name="txtSecondLastName" maxlength="50" class="form-control">

                                         </div>
                                    </div>
                               </div>
                               <div class="row person-data">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Genero</label><span class="requiredfield">*</span>
                                            <select class="form-control input-person-data" id="optGender" name="optGender" >
                                                <option v-for="(index,key) in jsonSelect.arr_peoples_genders" :value="key">{{index}}</option>
                                            </select>                            
                                         </div>
                                    </div>

                               </div>
                               <div class="row">
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Email</label>
                                             <input type="email" id="txtEmail" style="text-transform: lowercase" name="txtEmail" maxlength="150" class="form-control">                         
                                         </div>
                                    </div>
                               </div>
                               <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Teléfono Fijo</label>
                                             <input type="text" id="txtLandline" style="text-transform: uppercase" name="txtLandline" maxlength="7" class="form-control">
                                         </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Teléfono Móvil</label>
                                            <input type="text" id="txtCellPhone" style="text-transform: uppercase" name="txtCellPhone" maxlength="10" class="form-control">
                                         </div>
                                    </div>
                               </div>
                               <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Dirección De Residencia</label>
                                              <input type="text" id="txtAddress" style="text-transform: uppercase" name="txtAddress" maxlength="200" class="form-control">
                                         </div>
                                    </div>
                               </div>
                              
                            </div>
                        </div> 
                       
                    </div>
                    
                </div> 
               <div class="box-footer">
                   <div class="row">
                        <div class="col-md-12">
                           <div class="button-group">
                               <input type="hidden" id="txtHdDataRolPerson"  name="txtHdDataRolPerson" value=""/>
                             </div>    
                       </div>    
                   </div> 
                   <div class="row">
                        <div class="col-md-12">
                           <div class="button-group">
                               <button type="button" class="btn btn-info waves-effect waves-light" id="btnSave" name="btnSave"> <i class="fa fa-save"></i>Guardar</button>
                               <button type="reset" class="btn waves-effect waves-light btn-light"> <i class="fa fa-eraser"></i>Limpiar</button>
                               <button type="button" class="btn waves-effect waves-light btn-danger" data-widget-modal="remove"> <i class="fas fa-window-close"></i>Cancelar</button>
                           </div>    
                       </div>    
                   </div> 
               </div>
           </form>
       </div>  
   </div>
    
</div>
 
 
    
</div>
    </div>
</template>
<script type="text/javascript">
import DataTable from './dataTable.vue'
import VdtnetTable from 'vue-datatables-net'

     export default{
         components: {DataTable,VdtnetTable},
        data() {
            return {
                jsonSelect:'',
                action:0
            }
        },
        methods:{
           
            constrolIdenTypePerson(event)
            {
                 var value=event.target.value;
                 constrolIdenTypePerson(value,'txtIdentificationNumber');
            },
            showFieldPersonType(event)
            {
                 var value=event.target.value;
                 $( "#dvVerificationDigit" ).text('');
                 $("#txtIdentificationNumber").val('');
                if(value>0)
                {
                    if(value==="1")
                    {
                      $('.person-data').hide(); 
                      $('.company-data').show();
                       $("#txtIdentificationNumber").attr('maxlength','9');
                      if(this.action===1)
                       clearFieldByClass('input-person-data');
                   
                      
                    }
                    else
                    {
                      $('.company-data').hide();
                      $('.person-data').show();
                      $("#txtIdentificationNumber").attr('maxlength','16');
                    }
                }
                else
                {
                   $('.person-data').hide(); 
                   $('.company-data').hide();
                  if(this.action===1)
                    clearFieldByClass('input-person-data');
                }
            }
            
        },
         
        mounted() {
             var arrInputSelect = new Array();
         


         var dataSubConsult = {   
                "table":'settings.identification_configurations_types',
                "fillable":'identification_type_id',
                "field":'person_type_id',
                "input":"optPersonType",
                "operator":"=",
                "tag":"select"
            };       
                
         arrInputSelect[0]= {
                   table:'settings.identifications_types',
                   orderBy:'identification_type_name',
                   id:'id',
                   opt:'optPersonType',
                   name:'identification_type_name',            
                   select:'optIdentificationType',  
                   arrFilter:[{"field":"id","subConsult":true,"data_sub_consult":dataSubConsult}],
                   showLoading:true
                };
            selectDependent(arrInputSelect);
            
            $("#txtIdentificationNumber").blur(function()
            {
                if($("#optPersonType").val()==1&&$(this).val().trim().length>8)
                {
                     var params = {identificationNumber: $(this).val().trim()};
                     var sendData = jQuery.param(params);   // arbitrary variable name
                     var obj = 
                         {
                                type: 'POST',
                                url: '/util/getVerificationDigit',
                                dataSend: sendData,
                                return : true
                          };
                    var verificationDigit = requestAjaxNotFrm(obj);
                     $('.company-data').show(); 
                     $( "#dvVerificationDigit" ).text(verificationDigit);
                }
                else
                {
                    $('.company-data').hide(); 
                }
		
            });
            
            
             var objInputFrm = {          
                txtCellPhone: 'number'  
                
            };
            checkFieldInputFrm(objInputFrm); 
            
        },
         created(){
         
         var params = { select: 1};
         var sendData = jQuery.param(params);   // arbitrary variable name
         var obj = 
              {
                     type: 'GET',
                     url: '/administration/people/create',
                     dataSend: sendData,
                     return : true
               };
         var response = requestAjaxNotFrm(obj);
         this.jsonSelect=response;
    }
    }
</script>