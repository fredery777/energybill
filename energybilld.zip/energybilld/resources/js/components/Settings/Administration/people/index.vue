<template>
    
    <div>
<!--*********** Start modals ************ -->
<modals ref="modals"></modals>
<!-- *********** End modals *********** -->

<!--Frm Consult-->
<form class="form pt-3" id="frmConsult" name="frmConsult" onsubmit="return false;">
    
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label>Tipo</label>
             <select class="form-control" id="optPersonTypeConsult" name="optPersonTypeConsult" >
                <option v-for="(index,key) in jsonSelect.arr_people_types" :value="key">{{index}}</option>
            </select>                                 
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
             <label>Estado</label>
             <select class="form-control" id="optPersonStatusConsult" name="optPersonStatusConsult" >
                <option v-for="(index,key) in jsonSelect.arr_people_status" :value="key">{{index}}</option>
            </select>      
        </div>
    </div>
</div>    
   
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label>Tipo Identificación</label>
              <select class="form-control" id="optIdentificationTypeConsult" name="optIdentificationTypeConsult" >
                <option v-for="(index,key) in jsonSelect.arr_identifications_types" :value="key">{{index}}</option>
            </select>                             
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
             <label>Nro Identificación</label>
            <input type="text" id="txtIdentificationNumberConsult" style="text-transform: uppercase" name="txtIdentificationNumberConsult" maxlength="20" class="form-control">
    
        </div>
    </div>
</div>    
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label>Primer Nombre</label>
             <input type="text" id="txtFirstNameConsult" style="text-transform: uppercase" name="txtFirstNameConsult" maxlength="60" class="form-control">          
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label>Segundo Nombre</label>
             <input type="text" id="txtSecondNameConsult" style="text-transform: uppercase" name="txtSecondNameConsult" maxlength="60" class="form-control">          
        </div>
    </div>
   
</div>    
<div class="row">
     <div class="col-md-6">
        <div class="form-group">
             <label>Primer Apellido</label>
            <input type="text" id="txtFirstLastNameConsult" style="text-transform: uppercase" name="txtFirstLastNameConsult" maxlength="60" class="form-control">
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label>Segundo Apellido</label>
            <input type="text" id="txtSecondLastNameConsult" style="text-transform: uppercase" name="txtSecondLastNameConsult" maxlength="60" class="form-control">              
        </div>
    </div>
</div>           
<hr>
<div class="row">
 <div class="col-md-12">
    <div class="button-group">
        <button type="button" class="btn btn-info waves-effect waves-light" id="btnBusq" @click="consult()"> <i class="fa fa-search"></i>Buscar</button>
        <button type="button" class="btn waves-effect waves-light btn-secondary"  id="btnFrmStoragePeople" @click="frmStorage()"> <i class="fa fa-plus-square"></i>Crear</button>
        <button type="reset" class="btn waves-effect waves-light btn-light"> <i class="fa fa-eraser"></i>Limpiar</button>
    </div>    
</div>    
</div>    
</form>
    <!--Table Consult-->   
    <div class="box_table">
        <!-- Using the VdtnetTable component -->
        <vdtnet-table 
            ref="tableConsult"
            :fields="fieldsConsult"
            :opts="optionsConsult"
            @delete="deleteFrm"
            @edit="editFrm"
            @activatePerson="activatePerson"
            />

    </div>
<!--End Frm Consult-->
</div>
</template>
<script type="text/javascript">
import modals from './modals.vue'
import DataTable from './dataTable.vue'
import VdtnetTable from 'vue-datatables-net'

export default
{
    components: {DataTable,VdtnetTable,modals},
    data(){
        return {
                 jsonSelect:'',
                 optionsConsult:DataTable.data().optionsConsult,
                 fieldsConsult:DataTable.data().fieldsConsult
            }

    },
    methods:{
        consult(){
            const table = this.$refs.tableConsult; //table ref
            table.reload();
        },
        frmStorage(){
            
                $('.company-data').hide(); 
                $('.person-data').show(); 
                $( "#navPersonData" ).removeClass( "active" ).addClass( "active" );
                $( "#personData" ).removeClass( "active" ).addClass( "active" );

                $("#optPersonType").removeAttr("data-selected");
                $('#btnSave').unbind('click');
                $('#btnSave').html('<i class="fa fa-save"></i>Guardar');
                $('#dvTitleFrmCreatedAndEdit').html('Crear Persona');
                clearForm('frmPeople');

                $('#btnSave').click(function ()
                {
                    var personType=$('#optPersonType').val();
                    var objValidate = 
                    {
                        optPersonType: {required: true, name: "Tipo Persona"},
                        optIdentificationType: {required: true, name: "Tipo Identificación"},
                        txtIdentificationNumber: {required: true, name: "Nro Identificación"},
                        txtFirstName: {required: true, name: "Primer Nombre"}
                       
                    };
                    if(personType==="2")
                    {
                         objValidate.optGender = {required: true, name: "Genero"};
                         objValidate.txtFirstLastName = {required: true, name: "Primer Apellido"};
                    }

                    if(validate(objValidate))
                    {
                         
                 
                        requestAjax({
                                type: 'POST',
                                url: '/administration/people',
                                form: 'frmPeople',
                                success: 'Persona Creada Satisfactoriamente',
                                div: 'dvFrmCreatedAndEdit',
                                hide: true,
                                resetForm: true,
                                clickButton: 'btnBusq'
                                });
    
                    }
                });
                showDiv('dvFrmCreatedAndEdit');
        },
        editFrm(data) {
           
                 $('.company-data').hide(); 
                 $('.person-data').show(); 
                 
               
                $( "#navPersonData" ).removeClass( "active" ).addClass( "active" );
             
                $( "#personData" ).removeClass( "active" ).addClass( "active" );
                
               
           
            $("#optPersonType").removeAttr("data-selected");
                 
            $('#btnSave').unbind('click');
            $('#btnSave').html('<i class="fa fa-save"></i>Modificar');
            $('#dvTitleFrmCreatedAndEdit').html('Modificar Persona');
            clearForm('frmPeople');
            var objRequest = {type: 'GET', url: '/administration/people/' + data.id + '/edit', return:true};
            var jsonRta = requestAjax(objRequest);
            //Assign form values returned from the controller
            assignDataFrm(jsonRta);
            
           
            
            $('#btnSave').click(function () {
                   var personType=$('#optPersonType').val();
                    var objValidate = 
                    {
                        optPersonType: {required: true, name: "Tipo Persona"},
                        optIdentificationType: {required: true, name: "Tipo Identificación"},
                        txtIdentificationNumber: {required: true, name: "Nro Identificación"},
                        txtFirstName: {required: true, name: "Primer Nombre"}
                       
                    };
                    if(personType==="2")
                    {
                         objValidate.optGender = {required: true, name: "Genero"};
                         objValidate.txtFirstLastName = {required: true, name: "Primer Apellido"};
                    }
                    
                    if(validate(objValidate))
                    {
                          
                        
                        var objButton = {
                            type: 'PUT',
                            url: '/administration/people/' + data.id,
                            form: 'frmPeople',
                            div: 'dvFrmCreatedAndEdit',
                            hide: true,
                            success: 'Persona Actualizada satisfactoriamente',
                            clickButton: 'btnBusq'
                        };
                     }
                requestAjax(objButton);
            });
           showDiv('dvFrmCreatedAndEdit');
            if(jsonRta.optPersonType===1)
            {
                 $('.company-data').show(); 
                 $('.person-data').hide(); 
            }

        },
        deleteFrm(data) {
            
            Swal.fire({
                title: 'Seguro desea eliminar?',
                text: "Eliminar la pagina "+data.name+"!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si',
                cancelButtonText: 'No'
            }).then((result) => 
            {
                if (result.value) {
                   var objButton = {
                        type: 'DELETE',
                        url: '/administration/people/' + data.id,
                        form: 'frmConsult',
                        success: 'Persona Eliminada satisfactoriamente',
                        clickButton: 'btnBusq'
                    };
                    requestAjax(objButton);
                }
            });
        },
        activatePerson(data)
        {
            var activate = data.person_status_id==="1" ? 3 : 1;
            var params = { person_status_id: activate,id: data.id};
            var sendData = jQuery.param(params);   // arbitrary variable name
            var obj = 
                 {
                        type: 'POST',
                        url: '/administration/people/modPerson',
                        dataSend: sendData,
                        clickButton: 'btnBusq',
                        success: 'Persona Actualizada satisfactoriamente',
                  };
            requestAjaxNotFrm(obj);
        }
       
    },
    mounted(){
        
        $('#titlePag').html('Personas');
    },
    created(){
         
         
        var params = { select: 1};
         var sendData = jQuery.param(params);   // arbitrary variable name
         var obj = 
              {
                     type: 'GET',
                     url: '/administration/people/create',
                     dataSend: sendData,
                     return : true
               };
         var response = requestAjaxNotFrm(obj);
         this.jsonSelect=response;
    }

}
</script>