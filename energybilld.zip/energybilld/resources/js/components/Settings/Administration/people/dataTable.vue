<script>
    
    export default{
        components:{
        },
       
        data() {
            return {
                optionsConsult: {
                    ajax: {
                      url:'/administration/people',
                      data: function (d) 
                      {
                            $('#frmConsult').find(':input').each(function () 
                            {
                                var element = this;
                                if (element.id != null) {
                                     d[element.id] = getDataFrmTb(element);
                                }
                            });
                       }
                    },
                    autoWidth: true,
                    responsive: false,
                    lengthMenu: [[15, 25, 50, 100],[15, 25, 50,100]],
                    processing: true,
                    searching: false,
                    destroy: true,
                    serverSide: true,
                    language: {
                                zeroRecords: "",
                                url: "/assets/plugins/dataTables/langs/Spanish.json",
                             }
                  },
                  
                  fieldsConsult:
                  {
                    id:{label: 'Cod',name: 'id', sortable: false},
                    identification_type_name:{label: 'Tipo&nbsp;Identificación',name:'identification_type_name', sortable: false},
                    identification_number:{label: 'Nro&nbsp;Identificación',name: 'identification_number', sortable: false},
                    verification_digit:{label: 'Dig.Verif',name: 'verification_digit', sortable: false},
                    name:{label: 'Nombre',name: 'name', sortable: false},
                    person_type_name:{label: 'Tipo&nbsp;Persona',name: 'person_type_name', sortable: false},
                    address:{label: 'Dirección',name: 'address', sortable: false},
                    person_status_name:{label: 'Estado',name: 'person_status_name', sortable: false},
                    buttons: {
                        sortable: false,
                        label: '______________________',
                        render: (data) => {
                             var  obj=b64ToUtf8(data);
                             var jsonObj = JSON.parse(obj);
                             var str='';
                            
    
                                 if(jsonObj.person_status_id===1)
                                 {
                                    str=str+'<span data-action="activatePerson" class="btn-tb btn-pinterest btn-sm" title="Inactivar Persona"><i class="fas fa-power-off"></i></span>&nbsp;';
                                 }
                                 else if(jsonObj.person_status_id===3)
                                 {
                                    str=str+'<span data-action="activatePerson" class="btn-tb btn-success btn-sm" title="Activar Persona"><i class="fas fa-power-off"></i></span>&nbsp;';
                                 }

                            if(jsonObj.person_status_id===1)
                            str=str+'<span data-action="edit" class="btn-tb btn-warning btn-sm" title="Editar Persona"><i class="fa fa-edit"></i></span>&nbsp;';

                            if(jsonObj.person_status_id===1)
                            str=str+'<span data-action="delete" class="btn-tb btn-googleplus btn-sm" title="Eliminar Persona"><i class="fa fa-times"></i></span>';
                             
                          return str;
                        }
                      }
                  }
               
                  
                 
                
            }
        },
        watch: {
        },
        mounted() {
            
        }
    }
</script>