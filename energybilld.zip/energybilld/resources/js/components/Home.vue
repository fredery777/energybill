<template>
    <div>
        <h1>Módulo de configuración </h1>
    </div>
</template>
<script type="text/javascript">

export default
{
    components: {},
    data(){
        return {
              
            }

    },
    methods:{
    },
    mounted(){
    },
    created(){}

}
</script>