  
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer">
    {!! Config::get('constants.options.copyright') !!} {!! env('COMPANY_NAME', 'forge') !!}  {!! Config::get('constants.options.recommendation') !!} 
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->