
    
     <!-- ============================================================== -->
    <!-- Functions js -->
    <!-- ============================================================== -->
 <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    {!! Html::script ('assets/plugins/jquery/jquery.min.js') !!}
    <!-- Bootstrap tether Core JavaScript -->
    {!! Html::script ('assets/plugins/bootstrap/js/popper.min.js') !!}
    {!! Html::script ('assets/plugins/bootstrap/js/bootstrap.min.js') !!}
    <!-- slimscrollbar scrollbar JavaScript -->
    {!! Html::script ('js/jquery.slimscroll.js') !!}
    <!--Wave Effects -->
     {!! Html::script ('js/waves.js') !!}
    <!--Menu sidebar -->
    {!! Html::script ('js/sidebarmenu.js') !!}
    <!--stickey kit -->
    {!! Html::script ('assets/plugins/sticky-kit-master/dist/sticky-kit.min.js') !!}
    <!--Custom JavaScript -->
    {!! Html::script ('js/custom.min.js') !!}
    <!-- ============================================================== -->
    <!-- Style switcher -->
    <!-- ============================================================== -->
    {!! Html::script ('assets/plugins/styleswitcher/jQuery.style.switcher.js') !!}
    <!-- ============================================================== -->
    <!-- Redirect -->
    <!-- ============================================================== -->
    {!! Html::script ('js/jquery.redirect.js') !!}
    
    
    


 
     
 </script>