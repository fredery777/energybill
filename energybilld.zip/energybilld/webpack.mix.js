const mix = require('laravel-mix');

/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel application. By default, we are compiling the Sass
 | file for the application as well as bundling up all the JS files.
 |
 */

mix.js(
[
    'public/assets/plugins/jquery/jquery.min.js',
    'public/js/datatables.min.js',
    'public/js/jquery-ui.min.js',

    'resources/js/app.js',
    'public/assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js',
    'public/js/jquery.slimscroll.js',
    'public/js/waves.js',
    'public/js/sidebarmenu.js',
    'public/assets/plugins/sticky-kit-master/dist/sticky-kit.min.js',
    'public/js/custom.min.js',
    'public/assets/plugins/toast-master/js/jquery.toast.js',
    'public/assets/plugins/styleswitcher/jQuery.style.switcher.js',
    'public/js/jquery.redirect.js',
    'public/assets/plugins/clockpicker/dist/jquery-clockpicker.min.js',
    'public/assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js',
    'public/assets/plugins/timepicker/bootstrap-timepicker.min.js',
    'public/assets/plugins/daterangepicker/daterangepicker.js',
    'public/js/chosen.jquery.js',
    'public/js/multi_field.js',
    'public/js/markerclusterer.js',
    'public/js/functions.js'
], 'public/js/app.js');