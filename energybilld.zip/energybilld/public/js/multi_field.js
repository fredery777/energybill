
 /*
	 * Plugin Options
	 * section (string) -  selector of the section which is located inside of the parent wrapper
	 * max (int) - Maximum sections
	 * btnAdd (string) - selector of the "Add section" button - can be located everywhere on the page
	 * btnRemove (string) - selector of the "Remove section" button - should be located INSIDE of the "section"
	 * locale (string) - language to use, default is english
	 */

	// our plugin constructor
	var multiField = function( elem, options){
		this.elem = elem;
		this.$elem = $(elem);
		this.options = options;
		// Localization
		this.localize_i18n='';
		

		// This next line takes advantage of HTML5 data attributes
		// to support customization of the plugin on a per-element
		// basis. For example,
		// <div class=item' data-mfield-options='{"section":".group"}'></div>
		this.metadata = this.$elem.data( 'mfield-options' );
	};

	// the plugin prototype
	multiField.prototype = {

		defaults: {
			max: 0,
                        onchange: 0,
                        dvResize: '',
                        count_td: 0,
			locale: 'default'
		},
		

		init: function() {
			var $this = this; //Plugin object
			// Introduce defaults that can be extended either
			// globally or using an object literal.
			this.config = $.extend({}, this.defaults, this.options,
				this.metadata);

			

			// Hide 'Remove' buttons if only one section exists
			if(this.getSectionsCount()<2) {
				$(this.config.btnRemove, this.$elem).hide();
			}
                        
                       

			// Add section
			this.$elem.on('click',this.config.btnAdd,function(e){
				e.preventDefault();
				$this.cloneSection();
			});

			// Remove section
			this.$elem.on('click',this.config.btnRemove,function(e){
                            
				e.preventDefault();
				var currentSection=$(e.target).closest($this.config.section);
                                $this.removeSection(currentSection);

			});

			return this;
		},

		

		/*
		 * Add new section
		 */
		cloneSection : function() {
			// Allow to add only allowed max count of sections
			if((this.config.max!==0)&&(this.getSectionsCount()+1)>this.config.max){
				return false;
			}
                       var onchange=this.config.onchange;
                       var count_td=this.config.count_td;
                       var dvResize=this.config.dvResize;
                       
                        var counter=this.getSectionsCount();
			// Clone del primer elemento
			var newChild = $(this.config.section, this.$elem).first().clone().attr('id', '').fadeIn('fast');
                        var onchangeSelect='';
                       
                       
                       // Clear input values
                         var id='';
                         var arrIdClon= new Array();
                         var post=0;
			$('input[type=text]', newChild).each(function () 
                        {
                            id=$(this).attr('id');
                            if (typeof id !== typeof undefined && id !== false)
                            {
                                  $(this).attr('id', id+counter);
                                  arrIdClon[post] =id; 
                                  post++;
                            }
				$(this).val(''); 
			});
                        
                       
                       var cantClon=0;
                       var txthidden='';
                        //select
                        $('select', newChild).each(function () 
                        {
                             id=$(this).attr('id');
                            if (typeof id !== typeof undefined && id !== false)
                            {
                                $(this).attr('id', id+counter); 
                            }
                               if(onchange!=='0')
                               {
                                   cantClon=0;
                                   onchangeSelect=$(this).attr('onchange');
                                    if(typeof onchangeSelect !== typeof undefined && onchangeSelect !== false)
                                    {
                                           for(cantClon=0;cantClon<arrIdClon.length;cantClon++)
                                           {
                                               txthidden=arrIdClon[cantClon].replace('TBUS', '');

                                               if(onchangeSelect.indexOf(txthidden) >= 0)
                                                {
                                                    onchangeSelect=onchangeSelect.replace(txthidden,txthidden+counter);
                                                    $(this).attr('onchange',onchangeSelect);
                                                }
                                           }
                                       }
                               }
			});
                       
                   
                        $('table', newChild).each(function () 
                        {
                                 $(this).addClass( "tbClone" );
                                 

                        }); 
                        			
                        
			$('input[type=hidden],textarea,input[type=password],img[type=button]', newChild).each(function () 
                        {
                            id=$(this).attr('id');
                            if (typeof id !== typeof undefined && id !== false)
                            {
                                  $(this).attr('id', id+counter);
                            }
                            $(this).val(''); 
			});
                        
			$('.specific', newChild).each(function () 
                        {
                            id=$(this).attr('id');
                            if (typeof id !== typeof undefined && id !== false)
                            {
                                  $(this).attr('id', id+counter);
                            }
                            $(this).val(''); 
			});

			// Fix radio buttons: update name [i] to [i+1]
			newChild.find('input[type="radio"]').each(function(){var name=$(this).attr('name');$(this).attr('name',name.replace(/([0-9]+)/g,1*(name.match(/([0-9]+)/g))+1));});
			// Reset radio button selection
			$('input[type=radio]',newChild).attr('checked', false);

			// Clear images src with reset-image-src class
			$('img.reset-image-src', newChild).each(function () {
				$(this).attr('src', '');
			});     
			// Append new section
			this.$elem.append(newChild);
                        
                        if(typeof dvResize !== typeof undefined && dvResize !== '')
                        {
                            $("#"+dvResize).resize();
                        }
                        
                        //agregacion de fechas y buscador
                        var className='';
                        post=0;
                        var optBusq='';
                        var idHiddenBusq='';

                        $('input[type=text]', newChild).each(function () 
                        {
                             className= $(this).attr('class');
                              
                             id=$(this).attr('id');
                             
                            if(typeof className !== typeof undefined && className !== false)
                            {
                                if(typeof id !== typeof undefined && id !== false)
                               {
                                 if(className.indexOf("ui-autocomplete-input") >= 0)
                                  {
                                     
                                    optBusq = $("#"+arrIdClon[post]).autocomplete( "option" );
                                    idHiddenBusq=id.replace('TBUS', '');
                                    var objSource={source:optBusq.source};
                                    
                                    
                                     searchTxt(''+idHiddenBusq+'',objSource,optBusq.minLength);
                                  }
                                  else if(className.indexOf("time_calendar") >= 0)
                                  {
                                     timeCalendar();
                                   }
                                    post++;
                                }
                           }
			});
                      
                       
			// Show 'remove' button
			$(this.config.btnRemove, this.$elem).show();
                        
		},

		/*
		 * Remove existing section
		 */
                    removeSection : function(section){
		
                        var sectionsCount = this.getSectionsCount();
                        var tbClone=section.find(".tbClone");
              
                          if(sectionsCount<2){
                                  $(this.config.btnRemove,this.$elem).hide();
                          }
                          if(tbClone.length>0)
                           section.slideUp('fast', function () {$(this).detach();});
                       
                       if(typeof this.config.dvResize !== typeof undefined && this.config.dvResize !== '')
                        {
                            $("#"+this.config.dvResize).resize();
                        }
                       
                       
		},

		/*
		 * Get sections count
		 */
		getSectionsCount: function(){
			return this.$elem.children(this.config.section).length;
		}

	};

	multiField.defaults = multiField.prototype.defaults;

	$.fn.multifield = function(options) {
		return this.each(function() {
			new multiField(this, options).init();
		});
	};
       
       