
/**
 * 
 * @returns {undefined}
 * description:show loader
 */
function showLoading() 
{
    showDiv('loadingAjax');
}
/**
 * 
 * @returns {undefined}
 * description:hide loader
 */
function hideLoading() {
    hideDiv('loadingAjax');
}

/*
 * Input:
 #@obj:Variable of type Object
 - type :Action to be execute out (Required)
 - url :Url where the ajax request will be made (Required)
 - form : Form from which the fields will be extracted (Required)
 - resetForm (true|false) :Indicates if you reset the form
 - cache :(true|false) Indicates if the query will be cached in the browser (Not mandatory)
 - success :Message to show if the transaction is satisfactory (optional)
 - function : Function to call if the request is satisfactory (optional)
 - div : Div where the form is (optional)
 - hide :(true|false) Indicates if you hide the div where the form is located (optional)
 - return :Indicates whether the server response returns
 */

function requestAjax(obj) {
   
   $.ajaxSetup({
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}
        });
        
    /**
     * uppercase fields before sending them to validations
     */
    $('#' + obj.form + ' input[type=text]').val(function ()
    {
        return this.value.toUpperCase().trim();
    });

   
   var modal=false;
   
   if(obj.hasOwnProperty('modal'))
   {
       modal=true;
   }
   
    var result = '';
    var jsonResult = '';
    $.ajax({
        type: obj.type,
        url: obj.url,
        cache: ((obj.hasOwnProperty('cache')) ? obj.cache : false),
        data: $('#' + obj.form).serialize(),
        dataType: 'json',
        async: false,
        beforeSend: function () {
            if (obj.hasOwnProperty('showLoading')) {
                showLoading();
            }
            //We eliminate classes from form errors
            $('form input, form select').removeClass('form-control-danger');
            $('.form-control-feedback').remove();
        },
        success: function (rta) {
            if (typeof rta != 'undefined')
            {
                if (rta.ErrorBd != null) {//If there is a database error, show the message      
                    SweetAlertError(rta.TlErrorBd,rta.ErrorBd);
                } else if (rta.Error) {
                   SweetAlertError(rta.ErrorPeril, rta.TlErrorPeril);
                    window.location.reload(true);
                } else if (rta.status == 'error') {
                   SweetAlertError(rta.content, "");
                } else {
                    //If you must show a satisfactory response message
                    if (obj.hasOwnProperty('success')) {
                        toastSuccess('',obj.success);
                    }
                    //Hide the div where the form is located
                    if (obj.hasOwnProperty('div') && obj.hasOwnProperty('hide') && obj.hide == true&&modal==false) {
                        hideDiv(obj.div);
                    }
                    if (obj.hasOwnProperty('div') && obj.hasOwnProperty('hide') && obj.hide == true&&modal==true) {
                        $('#'+obj.div).modal('hide');
                    }

                    //Check if you must call an additional function
                    if (obj.hasOwnProperty('function')) {
                        var fn = window[obj.function];
                        fn(rta.message);
                    }

                    //Reset the form
                    if (obj.hasOwnProperty('form') && obj.hasOwnProperty('resetForm') && obj.resetForm == true) {
                        clearForm(obj.form);
                    }

                    //Click button, to search once a record is modified
                    if (obj.hasOwnProperty('clickButton')) {
                        $("#" + obj.clickButton).trigger("click");
                    }
                }
                result = rta;
            } else {

                 SweetAlertError('Error', "No Answer Json!!");
            }
        },
        error: function (data)
        {
            //Process if I generate errors the ajax request.
            var jsonErrors = data.responseJSON;

            //If it is a form, it shows the error, below the field¡
            if (obj.hasOwnProperty('form'))
            {
               
               toastError('Error','There have been errors in the form');
                 
                if (jsonErrors.errors.hasOwnProperty('message'))
                {
                    if (jsonErrors.errors.message != "The given data was invalid.")
                    SweetAlertError('Error', jsonErrors.errors.message);
                }

                $.each(jsonErrors.errors, function (i, v)
                {
                    //If the element exists, it displays the message below the element, otherwise it shows a Toast message
                    if (existElem("#" + i))
                    {
                        var msg = '<small class="form-control-feedback">'+v+'</small>';
                        $('input[name="' + i + '"], select[name="' + i + '"]').addClass('form-control-danger').after(msg);
                    } else
                    {
                        if (v != 'error' && v.length > 2)
                            toastError('Error', v);
                    }
                });

                var keys = Object.keys(jsonErrors.errors);
                $('input[name="' + keys[0] + '"]').focus();
            } else
            {

                $.each(jsonErrors.errors, function (index, value) {
                    SweetAlertError('Error', value);
                });
            }
        }
    });

    if (obj.hasOwnProperty('showLoading')) {
        hideLoading();
    }

    if (obj.return == true)
        return result;
}
/**
 * 
 * @param {type} id
 * @returns {Boolean}
 * description:validate if an object exists in js
 */
function existObj(id)
{
    if (document.getElementById(id) != null)
        return true;
    else
        return false;
}
/**
 * 
 * @param {type} id
 * @returns {Boolean}
 * description:validate if an object exists in js
 */
function existElem(idElem) {
    return (($(idElem).length == 0) ? false : true);
}

/*
 * 
 * @param {type} heading
 * @param {type} text
 * @returns {undefined}
 * description:show satisfactory messages
 */
function toastSuccess(heading,text)
{
$.toast({
            heading: heading,
            text: text,
            position: 'top-right',
            loaderBg:'#ff6849',
            icon: 'success',
            hideAfter: 3500, 
            stack: 6
          });
}

/*
 * 
 * @param {type} heading
 * @param {type} text
 * @returns {undefined}
 * description:show error messages
 */

function toastError(heading,text)
{
$.toast({
            heading: heading,
            text: text,
            position: 'top-right',
            loaderBg:'#ff6849',
            icon: 'error',
            hideAfter: 3500, 
            stack: 6
          });
}

/*
 * 
 * @param {type} heading
 * @param {type} text
 * @returns {undefined}
 * description:show error messages
 */
function SweetAlertError(heading,text)
{
  Swal.fire({
                type: 'error',
                title: heading,
                text: text
                
            });
}

/**
 * 
 * @param {type} el
 * @returns {String|Boolean|jQuery}
 * Description:contains the search form info
 */
function getDataFrmTb(el)
{
    var fieldType = "";
    var data = '';
    fieldType = el.type.toLowerCase();
    switch (fieldType)
    {
        case "text":
        case "password":
        case "textarea":
        case "email":
        case "hidden":
        case "radio":
            data = $(el).val();
            break;
        case "checkbox":
            if (el.checked)
                data = true;
            else
                data = false;
            break;
        case "select-one":
        case "select-multi":
        case "select-multiple":
            data = $(el).val();
            break;
        default:
            break;
    }
    return data;
}

/*
 * 
 * @param {type} val
 * @param {type} type
 * @returns {Boolean}
 * Description:valid according to the regular expression
 */
function _validate(val, type) {
    var date = /^(\d{4})-([0][1-9]|[1][0-2])-([0][1-9]|[1-2]\d|[3][0-1])$/;
    var numbers = /^\d+$/;
    var mobile = /^\d+$/;
    var identification = /^\d+$/;
    var telephone = /^\d+$/;
    var email = /^[a-z]+@[a-z]+\.[a-z]{2,4}$/;
    var text = /^[A-Za-z]$/;
    var text_space = /^[A-Z a-z]$/;
    var decimal_number = /^-?[0-9]+([.][0-9]*)?$/;
    switch (type) {
        case "date":
            return date.test(val);
            break;
        case "numbers":
            return numbers.test(val);
            break;
        case "text":
            return text.test(val);
            break;
        case "text_space":
            return text_space.test(val);
            break;
        case "email":
            return email.test(val);
            break;
        case "decimal_number":
            return decimal_number.test(val);
            break;
        case "mobile":
            if (val.length == 10)
                return mobile.test(val);
            else
                return false;
            break;
        case "identification":
            if (val.length > 5)
                return identification.test(val);
            else
                return false;
            break;
        case "telephone":
            if (val.length == 7)
                return telephone.test(val);
            else
                return false;
            break;
        default:
            if (!val || val == 0)
                return false
    }
    return true
}
/**
 * 
 * @param {type} dat
 * @returns {Boolean}
 * Description:validate input data
 */
function validate(dat) {
    var fields = "";
    var val = "";
    var r = false;
    var msg="";
    $('form input, form select').removeClass('form-control-danger');
    $('.form-control-feedback').remove();
    
    for (var i in dat) 
    {
        if(existObj(i))
        {
            val = document.getElementById(i).value;
            if (val) {
                r = _validate(val, dat[i].type);
                if (!r) {
                    fields += (fields ? ", " : "") + dat[i].name;
                        msg = '<small class="form-control-feedback">este campo es requerido</small>';
                        $('input[name="' + i + '"], select[name="' + i + '"]').addClass('form-control-danger').after(msg);
 
                }
            } else if (dat[i].required) {
                fields += (fields ? ", " : "") + dat[i].name;
                msg = '<small class="form-control-feedback">este campo es requerido</small>';
                $('input[name="' + i + '"], select[name="' + i + '"]').addClass('form-control-danger').after(msg);

            }
            
       }
       else
        {
             SweetAlertError('ERROR','no exist  input con id:'+i);
        }
    }
    if (fields) {
        return false;
    } else
        return true;
}
/**
 * 
 * @param {type} idfrm
 * @returns {undefined}
 * Description:clear Form
 */
function clearForm(idfrm)
{
    var frmElements = document.getElementById(idfrm);
    for(var i = 0; i < frmElements.length; i++)
    {
        clearField(frmElements[i].id);
        if(i==0)
        {
            $( "#"+frmElements[i].id).focus();
        }
    }
}
/**
 * 
 * @param {type} idEl
 * @returns {undefined}
 * Description:clear Field
 */
function clearField(idEl)
{
    if (existObj(idEl))
    {
        $('form input, form select').removeClass('form-control-danger');
        $('.form-control-feedback').remove();
        var elementType=document.getElementById(idEl).type.toLowerCase();
        var elementObj=document.getElementById(idEl);
        switch (elementType)
        {
            case "text":
            case "email":
            case "password":
            case "textarea":
            case "hidden":
               elementObj.value = "";
                break;
            case "radio":
            case "checkbox":
                if (elementObj.checked)
                {
                    elementObj.checked = false;
                }
                break;
            case "select-one":
            case "select-multi":
            case "select-multiple":
                elementObj.selectedIndex = -1;

                if(elementObj.className.indexOf("chzn-select") >= 0)//if is un select chosen
                {
                    $("#" + idEl).val(0).trigger("chosen:updated");
                     var multiple = $("#" + idEl).attr('multiple');
                    if(typeof multiple !== typeof undefined) 
                    {
                        $("#" + idEl).val('').trigger("chosen:updated");
                    }

                }
                $('#'+idEl).val(0).change();

                break;
            default:
                break;
        }
    }
}
/**
 * 
 * @param {type} div
 * @returns {undefined}
 * show the div
 */
function showDiv(div)
{
    $('#'+div).show(); 
};
/**
 * 
 * @param {type} div
 * @returns {undefined}
 * hide the div
 */
function hideDiv(div)
{
    $('#'+div).hide();
};
/**
 * 
 * @param {type} str
 * @returns {undefined}
 * convert to base64
 */
function utf8ToB64(str) {
    return window.btoa(unescape(encodeURIComponent(str)));
}
/**
 * 
 * @param {type} str
 * @returns {unresolved}
 * decode base64
 */
function b64ToUtf8(str) {
    return decodeURIComponent(escape(window.atob(str)));
}

/**
 * 
 * @param {type} el
 * @returns {undefined}
 * drag element
 */
function drag(el)
{
    var element = $(el);
    if (typeof element === 'object')
    {
       element.draggable().css({"position": "absolute", "z-index": "900","top": "50%","cursor":"pointer","display":"none"});
    }  
}
/**
 * 
 * @param {type} arr
 * @param {type} value
 * @returns {Boolean}
 */
function arrayContain(arr, value) {
    var index = arr.indexOf(value);
    if (index < 0) {
        return false;
    } else {
        return true;
    }
}
/**
 * 
 * @param {type} idfrm
 * @param {type} arrDoNotUse
 * @returns {undefined}
 */
function usabilityFrm(idfrm, arrDoNotUse) {
    if (!existObj(idfrm))
    {
        SweetAlertError('Error','form '+idfrm+' no exist !!!');
    } else {
        var frm = document.getElementById(idfrm);
       
        var a = 0;
        var field;
        var fieldAnt;
        var objInputFrmVal = '';
        var existingFunction = '';
        var functionValue = '';
        var functionAdd = '';
        var existFn = 0;
        if (!arrDoNotUse) {
            arrDoNotUse = new Array();
        }

        for (var i = 0; i < frm.elements.length; i++) {
            var valid = arrayContain(arrDoNotUse, frm.elements[i].id);
            existFn = 0;
            if (frm.elements[i].type != 'hidden' && frm.elements[i].type != 'reset' && frm.elements[i].type != 'fieldset' && frm.elements[i].type != 'search' && !valid) {
                if (existObj(frm.elements[i].id)) {
                    if (a == 0) {
                        field = frm.elements[i].id;
                        $( "#"+field ).focus();
                    } else if (a > 0) {
                        fieldAnt = field;
                        field = frm.elements[i].id;
                        objInputFrmVal = document.getElementById(fieldAnt);
                         $( "#"+fieldAnt ).attr('autocomplete', 'off');
                       // Function Add
                        functionAdd = "if(event.keyCode==13){document.getElementById('" + field + "').focus();};";

                        if (objInputFrmVal.getAttribute("onkeypress"))
                        {
                           // if onkeypress already exists
                            existingFunction = objInputFrmVal.getAttribute("onkeypress");

                            existFn = containsWord(existingFunction, functionAdd);

                            // New Function
                            functionValue = functionAdd + existingFunction;


                            if (!existFn)
                                $("#" + fieldAnt).attr("onkeypress", functionValue);

                        } else {
                            $("#" + fieldAnt).attr("onkeypress", functionAdd);
                        }
                    }
                    a++;
                } else {
                }
            }
            if (frm.elements[i].type == 'reset') {
                i = frm.elements.length;
            }
        }
    }
}
/**
 * 
 * @param {type} objInput
 * @returns {undefined}
 * 

 Function that allows to validate the input type of a field type input html
 @autor Fredy Herrera
 @objInput: Type variable Object example:{txtCantMax: 'number',txtCantMax: 'number'};
                                                                       
 **/
 
function checkFieldInputFrm(objInput) {
    var objInputFrmVal = '';
    var existingFunction = '';
    var functionValue = '';
    var functionAdd = '';
    var existFn = 0;

    for (var idInput in objInput) {
        if (existObj(idInput)) {

            objInputFrmVal = document.getElementById(idInput);


            functionAdd = "return validateField(event,'" + objInput[idInput] + "');";


            if (objInputFrmVal.getAttribute("onkeypress")) {// if onkeypress already exists  


               // if onkeypress already exists
                existingFunction = objInputFrmVal.getAttribute("onkeypress");

                existFn = containsWord(existingFunction, functionAdd);

               // New Function
                functionValue = functionAdd + existingFunction;


                if (!existFn)
                    $("#" + idInput).attr("onkeypress", functionValue);



            } else {
                $("#" + idInput).attr("onkeypress", functionAdd);
            }
        }
    }
}

/**
 * 
 * @param {type} value
 * @param {type} Type
 * @returns {Boolean}
 * validate input data
 */
function validateField(value, Type)
{
    var key='';
    var final_key='';
    var pattern='';
    switch (Type)
    {
        case "number":
            key = (document.all) ? value.keyCode : value.which;
            // Backspace key to erase, always allows it
            if (key == 241)
                return false;//241: Ñ
            if (key == 0 || key == 8)
                return true;//0: TAB - 8 : Backspace
            // Entry pattern, in this case only accepts numbers
            pattern = /[[0-9]/;
            final_key = String.fromCharCode(key);
            return pattern.test(final_key);
            break;
        case "text":
            key = (document.all) ? value.keyCode : value.which;
             // Backspace key to erase, always allows it
            if (key == 241)
                return false;//241: Ñ
            if (key == 0 || key == 8)
                return true;//0: TAB - 8 : Backspace
           // Entry pattern, in this case only accepts letters
            pattern = /[A-Za-z]/;
            final_key = String.fromCharCode(key);
            return pattern.test(final_key);
            break;
        case "alfanumeric":
            key = (document.all) ? value.keyCode : value.which;
              // Backspace key to erase, always allows it
            if (key == 241)
                return false;//241: Ñ
            if (key == 0 || key == 8)
                return true;//0: TAB - 8 : Backspace 
            // Entry pattern, in this case only accepts letters and number
            pattern = /[a-zA-Z0-9]/;
            final_key = String.fromCharCode(key);
            return pattern.test(final_key);
            break;
        case "alfanumericEsp":
            key = (document.all) ? value.keyCode : value.which;
                return false;//241: Ñ
            if (key == 0 || key == 8 || key == 32)
                return true;//0: TAB - 8 : Backspace - 32: space bar
            
            pattern = /[a-zA-Z0-9]/;
            final_key = String.fromCharCode(key);
            return pattern.test(final_key);
            break;
        case "email":
            re = /^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,3})$/
            if (!re.exec(value))
            {
                SweetAlertError('Error','Email Error !!');
            }

            break;
        case "textEsp":
            key = (document.all) ? value.keyCode : value.which;
           
            if (key == 241)
                return false;//241: Ñ
            if (key == 0 || key == 8 || key == 32)
                return true;//0: TAB - 8 : Backspace - 32: space bar
            
            pattern = /[A-Za-z]/;
            final_key = String.fromCharCode(key);
            return pattern.test(final_key);
            break;
        case "numEsp":
            key = (document.all) ? value.keyCode : value.which;
          
            if (key == 241)
                return false;//241: Ñ
            if (key == 0 || key == 8 || key == 32)
                return true;//0: TAB - 8 : Backspace 
           
            pattern = /[a-zA-Z0-9]/;
            final_key = String.fromCharCode(key);
            return pattern.test(final_key);
            break;
        case "numDecimal":
            key = (document.all) ? value.keyCode : value.which;
           
            if (key == 241)
                return false;//241: Ñ
            if (key == 0 || key == 8 || key == 46)
                return true;//0: TAB - 8 : Backspace
           
            pattern = /[[0-9]/;
            final_key = String.fromCharCode(key);
            return pattern.test(final_key);
            break;
        default:

            break;
    }
}


/*
 * 
 * @returns {undefined}
 * Clean form
 */
function assignResetFrm()
{
    var x = document.forms;
    var i;
    var attr = '';
    for (i = 0; i < x.length; i++)
    {
        attr = $(x[i]).attr('id');

        if (typeof attr !== typeof undefined && attr !== false)
        {
            clearFrmBtnReset(x[i].id);

            usabilityFrm(x[i].id);
        }
    }
}
/**
 * 
 * @param {type} idfrm
 * @returns {undefined}
 * Clean form
 */
function clearFrmBtnReset(idfrm)
{
    var frm = document.getElementById(idfrm);
    var fieldType = '';
    var functionValue = '';

    for (var i = 0; i < frm.elements.length; i++)
    {
        fieldType = frm.elements[i].type.toLowerCase();
        if (fieldType == 'reset')
        {
            functionValue = 'clearForm(\'' + idfrm + '\');';
            $(frm.elements[i]).attr("onclick", functionValue);
        }
        if (fieldType == 'text')
        {
            $(frm.elements[i]).attr("autocomplete", 'off');
        }
    }
}




/**
 Function that searches for a word from a String
 haystack:string
needle:text to search
 * 
 * @param {type} haystack
 * @param {type} needle
 * @returns {Boolean}
 */

function containsWord(haystack, needle) {

    var str = haystack;
    var found = false;

    if (str.includes(needle))
    {
        found = true;
    }

    return found;
}
/**
 * 
 * @param {type} jsonRta
 * @returns {undefined}
 * Assign form values returned from the controller
 */

function assignDataFrm(jsonRta) 
{
     var attrData=false;
     var arrElement='';
    $.each($.parseJSON(JSON.stringify(jsonRta)), function (key, value) 
    {
        
         attrData=containsWord(key, 'data-');
         if(attrData)
         {
              arrElement = key.split('|');
             if(existElem("#"+arrElement[0]))
             {
                   $('#'+arrElement[0]).attr(arrElement[1], value);
             }
         }
         
        if(!attrData)
        {
            if (existElem("#" + key))
            {
                var type = null;
                
               if(typeof document.getElementById(key).type !== typeof undefined) 
               {
                 type = document.getElementById(key).type.toLowerCase();
               }
                
                var tagName = $('#' + key).prop("tagName");

                switch (tagName)
                {
                    case "IMG":
                        $('#' + key).prop('src', value);
                        break;
                    case "DIV":
                        $('#' + key).html(value);
                        break;
                }

                if (type != null)
                {
                    switch (type)
                    {
                        case "checkbox":
                        case "radio":
                            if (value == true)
                            {
                                $("#" + key).trigger("click");
                            } else
                            {
                                $('#' + key).prop('checked', value);
                            }
                            break;
                        case "select-one":
                        case "select-multi":
                        case "select-multiple":
                            $('#' + key).val(value).change();

                            if (document.getElementById(key).className.indexOf("chzn-select") >= 0)//if is un select chosen
                            {
                                $('#' + key).val(value).trigger("chosen:updated");
                            }
                            break;
                        case "text":
                        case "password":
                        case "textarea":
                        case "email":
                        case "hidden":
                            $('#' + key).val(value);
                            break;
                    }
                }
            }
        }
       
    });
}
/**
 * validate by regular expression the email
 * @param {type} email
 * @returns {Boolean}
 */
function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}
/**
 * 
 * @param {type} el
 * @param {type} mlsc
 * @returns {unresolved}
 */
function hideTimeEl(el, mlsc) {
	var time = mlsc ? mlsc : 7000;
	var id = el ? el : 'info';
        var fn = function() {showDiv(el);}
        hideDiv(el);
	return setTimeout(fn, time);
}

/**
 * 
 * @param {type} frmId
 * @returns {Array|Object}
 */
function fieldsFrmToObj(frmId)
{
    var obj;
    if(existObj(frmId))
    {
        var data=$('#'+frmId).serialize();
        var arrData = data.split('&');
        var arrDataDet;
        var strObj='{';
        strObj=strObj+'"_token":"'+$('meta[name="csrf-token"]').attr('content')+'",';
          $.each(arrData, function (key, value)
            {
                arrDataDet = value.split('=');
                strObj=strObj+'"'+arrDataDet[0]+'":"'+arrDataDet[1]+'",';

            });
        strObj=strObj.slice(0, -1);
        strObj=strObj+'}';
        obj = JSON.parse(strObj);
    }
    else
    {
        console.log("No exist id:"+frmId);
    }
        
    return obj;
}

function requestAjaxNotFrm(obj)
{
   $.ajaxSetup({
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}
        });
        
    var result = '';
    var dataSend = obj.dataSend;
if (obj.hasOwnProperty('showLoading')) {
        showLoading();
    }
    $.ajax({
        type: obj.type,
        url: obj.url,
        cache: ((obj.hasOwnProperty('cache')) ? obj.cache : false),
        data: dataSend,
        dataType: 'json',
        async: false,
        beforeSend: function () {
              if (obj.hasOwnProperty('showLoading')) {
                showLoading();
            }
        },
        success: function (rta) {
            if (typeof rta != 'undefined')
            {
                if (rta.ErrorBd != null) 
                {             
                     SweetAlertError('Error', rta.TlErrorBd);
                } else if (rta.Error) {
                    SweetAlertError(rta.ErrorPeril,rta.TlErrorPeril);
                    window.location.reload(true);
                } else if (rta.status == 'error') {
                        SweetAlertError('Error',rta.content);
                } else {
                    if (obj.hasOwnProperty('success')) {
                        toastSuccess('',obj.success);
                    }
                    if (obj.hasOwnProperty('div') && obj.hasOwnProperty('hide') && obj.hide == true) {
                        hideDiv(obj.div);
                    }
                    if (obj.hasOwnProperty('function')) {
                        var fn = window[obj.function];
                        fn(rta.message);
                    }
                    if (obj.hasOwnProperty('clickButton') && obj.hasOwnProperty('clickButton')) {
                        $("#" + obj.clickButton).trigger("click");
                    }
                }
                result = rta;
            } else {
               
                 SweetAlertError('',"No Existe Respuesta Json!!");
            }
        },
        error: function (data)
        {
            var jsonErrors = data.responseJSON;
            $.each(jsonErrors.errors, function (index, value) {

               
                SweetAlertError('',value);
            });


        }
    });
    if (obj.hasOwnProperty('showLoading')) {
        hideLoading();
    }
    if (obj.return == true)
        return result;
}


/*
 * Input:
 #objData:Variable of type Object
 onSelect:just the name of the function after loading the ejm onSelect field:'search_person_client'
 */
function textFinder(ArrObjData) {
    var ArrData = new Array();
    if (ArrObjData instanceof Array) {
        ArrData = ArrObjData;
        for (var i = 0; i < ArrData.length; i++) {
            var objData = ArrData[i];
            loadTextSearch(objData);
        }
    } else {
        loadTextSearch(ArrObjData);
    }
    return true;
}
function loadTextSearch(objData) {
    var url = '/search/autocomplete';
    var length = 2;
    var dataObj = {
        route: objData.route,
        general: true,
        destroy: false,
        method: 'search_filter',
        table: '',
        model: '',
        filter: '',
        fillable: '',
        onSelect: ''
    };

    if (objData.table) {
        dataObj.table = objData.table;
        dataObj.general = false;
    } else {
        dataObj.model = objData.model;
    }
    if (objData.method) {
        dataObj.method = objData.method;
    }
    if (objData.filter) {
        dataObj.filter = objData.filter;
    }
    if (objData.fillable) {
        dataObj.fillable = objData.fillable;
    }
    if (objData.url) {
        url = objData.url;
    }
    if (objData.length) {
        length = objData.length;
    }
    
    var objSource={source: function (request, response) {
            $.ajaxSetup({headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}});
                $.ajax({
                    url: url,
                    type: 'POST',
                    dataType: "json",
                    data: {
                        term: request.term,
                        model: dataObj.model,
                        table: dataObj.table,
                        where: dataObj.filter,
                        fillable: dataObj.fillable,
                        route: dataObj.route,
                        general: dataObj.general,
                        method: dataObj.method
                    },
                    success: function (data) {
                        response(data);
                    }
                });
            }};
        
 
  if(objData.destroy)
  {
     if(document.getElementById('TBUS' + objData.input).className.indexOf("ui-autocomplete-input") >= 0)
     {
       $('#TBUS' + objData.input ).autocomplete("destroy");
     }
  }
 
 
    searchTxt(objData.input,objSource,length);

    if (objData.onSelect)
    {
        $('#TBUS' + objData.input).bind("autocompleteselect", function (event, ui)
        {
            var idSelected = ui.item.id;
            var funcion_select = objData.onSelect + '(\'' + idSelected + '\');';

            eval(funcion_select);//called of the function


        });
    }
}

 var searchTxt = function(idTxtSearch,objSource,length){

           $('#TBUS' + idTxtSearch).autocomplete({
            source:objSource.source,
            minLength: length,
            autoFocus: true,
            zIndex: 1000,
            select: function (event, ui) {
                $('#' +idTxtSearch).val(ui.item.id);
            }
        });
           
           
       };

function selectDependent(ArrObjData) 
{
    var ArrData = new Array();
    if (ArrObjData instanceof Array) {
        ArrData = ArrObjData;
        for (var i = 0; i < ArrData.length; i++) {
            var objData = ArrData[i];
            loadSelectDependent(objData);
        }
    } else {
        loadSelectDependent(ArrObjData);
    }
    return true;
}


function loadSelectDependent(objData)
{
    $('#'+objData.opt).unbind('change');
    
    $('#'+objData.opt).on('change', function () 
    { 
            var filter='';
            if(objData.hasOwnProperty('arrFilter'))
            {
                $.each(objData.arrFilter, function (index, jsonData) 
                {
                   if(!jsonData.hasOwnProperty('subConsult'))
                   {
                        if(jsonData.hasOwnProperty('type'))
                         {
                              filter=filter+' '+jsonData.type+' ';
                         }

                        filter=filter+' '+jsonData.field+' '+jsonData.operator+' ';
                         if(jsonData.hasOwnProperty('tag'))
                         {
                              filter=filter+$("#"+jsonData.input).val();
                         }
                         else
                         {
                             if(jsonData.input.toUpperCase()=='NULL')
                                 filter=filter+'NULL'; 
                              else
                               filter=filter+jsonData.input; 
                         }
                   }
                   else
                   {
                        filter=filter+loadFiltersubConsultSelect(jsonData.field,jsonData.data_sub_consult);
                   }
                     
                });
                objData.filter=filter;
                //delete objData.opt;
             }
             var selected = $('#'+objData.opt).attr('data-selected');
            // For some browsers, `attr` is undefined; for others,
            // `attr` is false.  Check for both.
            if(typeof selected !== typeof undefined) 
            {
               objData.selected =  selected;
            }
            else
            {
                delete objData.selected; 
            }
            var sendData = jQuery.param(objData);   // arbitrary variable name
            var obj = {
                type: 'POST',
                url: '/util/generateSelect',
                dataSend: sendData,
                return: true
            };
            
            if(objData.hasOwnProperty('showLoading'))
            {
               obj.showLoading=true; 
            }
            var rta = requestAjaxNotFrm(obj);
            generateSelect(rta);
     });
     
}

function loadFiltersubConsultSelect(field,objData)
{
    var filter='';
    if(objData.hasOwnProperty('type'))
    {
             filter=filter+' '+filter.type+' ';
    }
     filter=filter+field+' IN(';
     filter=filter+' SELECT '+objData.fillable+' FROM '+objData.table;
     
     if(objData.hasOwnProperty('field')&&objData.hasOwnProperty('filter'))
     {
       
        filter=filter+' WHERE '+objData.field+' IN(';

         var objFilter=objData.filter;
         
          if(objFilter instanceof Array) 
          {
                $.each(objFilter, function (index, jsonDataFilter) 
                {
                    if(objFilter.hasOwnProperty('filter'))
                    {
                        loadFiltersubConsultSelect(jsonDataFilter.field,jsonDataFilter)
                    }
                    else
                    {
                        
                       filter=filter+' SELECT '+jsonDataFilter.fillable+' FROM '+jsonDataFilter.table;
                        filter=filter+' WHERE ';
                       filter=filter+' '+jsonDataFilter.field+' '+jsonDataFilter.operator+' ';
                       if(jsonDataFilter.hasOwnProperty('tag'))
                       {
                            filter=filter+$("#"+jsonDataFilter.input).val();
                       }
                       else
                       {
                           if(jsonDataFilter.input.toUpperCase()=='NULL')
                               filter=filter+'NULL'; 
                            else
                             filter=filter+jsonDataFilter.input; 
                       }
                        
                    }
                });
          }
          else
          {
              filter=filter+' SELECT '+objFilter.fillable+' FROM '+objFilter.table;
              filter=filter+' WHERE ';
            
              
               filter=filter+' '+objFilter.field+' '+objFilter.operator+' ';
                if(objFilter.hasOwnProperty('tag'))
                {
                     filter=filter+$("#"+objFilter.input).val();
                }
                else
                {
                    if(objFilter.input.toUpperCase()=='NULL')
                        filter=filter+'NULL'; 
                     else
                      filter=filter+objFilter.input; 
                }
              
              
          }
          filter=filter+')';
     }
     else
     {
             filter=filter+' WHERE ';
            
              
               filter=filter+' '+objData.field+' '+objData.operator+' ';
                if(objData.hasOwnProperty('tag'))
                {
                     filter=filter+$("#"+objData.input).val();
                }
                else
                {
                    if(objData.input.toUpperCase()=='NULL')
                        filter=filter+'NULL'; 
                     else
                      filter=filter+objData.input; 
                }
     }

     filter=filter+')';
  return filter;
       
}
function generateSelect(json) {
    var arr = json.data;
    var select = $('#' + json.select);
    var selectedValue ="";
    select.empty();
    $.each(arr, function (key, value)
    {
        select.append('<option value=' + value.id + '>' + value.value + '</option>');
        if(value.hasOwnProperty('selected')) 
        {
            selectedValue=value.id.toString(); 
        } 

    });
    
    if(selectedValue.length>0)
    {
        select.val(selectedValue).change();
        select.val(selectedValue).trigger("chosen:updated");
    }
    else
    {
        select.trigger("chosen:updated");
    }
 
    return true;
}
function constrolIdenTypePerson(identType,idElControl)
{
    var objInputFrm='{';
    var functionOld='';
    var existingFunction='';
    var functionValue='';
    var existFn=false;
   var objInputFrmVal = document.getElementById(idElControl);
    
    if(identType==="4")//C.E
    {
        objInputFrm=objInputFrm+'"'+idElControl+'":"alfanumeric"';
        functionOld = "return validateField(event,'number');";
        
         existingFunction = objInputFrmVal.getAttribute("onkeypress");
         existFn = containsWord(existingFunction, functionOld);
         if(existFn)
         {
             functionValue = existingFunction.replace('number', 'alfanumeric');
             $("#" + idElControl).attr("onkeypress", functionValue);
         }
      
    }
    else
    {
         objInputFrm=objInputFrm+'"'+idElControl+'":"number"';
         functionOld = "return validateField(event,'alfanumeric');";
         existingFunction = objInputFrmVal.getAttribute("onkeypress");
         existFn = containsWord(existingFunction, functionOld);
         if(existFn)
         {
             functionValue = existingFunction.replace('alfanumeric', 'number');
             $("#" + idElControl).attr("onkeypress", functionValue);
         }
    }
    
    objInputFrm=objInputFrm+'}';
    
     checkFieldInputFrm(JSON.parse(objInputFrm)); 
}

function timeCalendar()
{
    $(function ()
    {

      var  objLocate = 
                    {
                "format": "YYYY-MM-DD",
                "separator": " - ",
                "applyLabel": "Apply",
                "cancelLabel": "Cancel",
                "fromLabel": "From",
                "toLabel": "To",
                "customRangeLabel": "Custom",
                "daysOfWeek": [
                    "Dom",
                    "Lun",
                    "Mar",
                    "Mie",
                    "Jue",
                    "Vie",
                    "Sáb"
                ],
                "monthNames": [
                    "Enero",
                    "Febrero",
                    "Marzo",
                    "Abril",
                    "Mayo",
                    "Junio",
                    "Julio",
                    "Agusto",
                    "Septiembre",
                    "Octubre",
                    "Noviembre",
                    "Diciembre"
                ],
                "firstDay": 1
            
        };
        
        $('.time_calendar').each(function ()
        {
            var self = $(this);
            var dataOpt = self.attr('data-opt');
            dataOpt = dataOpt.replace(/['()|[\]\\]/g, "\"");

            var objOpt = JSON.parse(dataOpt);
            objOpt.locale=objLocate;
            self.daterangepicker(objOpt);
            if(objOpt.hasOwnProperty('clear'))
            {
                if(objOpt.clear)
                {
                    clearField(self.attr('id'));
                }
            }
        });
    });

    return true;
}