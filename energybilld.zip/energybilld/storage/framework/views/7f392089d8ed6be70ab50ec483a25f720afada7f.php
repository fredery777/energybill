<?php echo Html::script ('js/vue/app_vue_456bd51c-0cfe-4797-87e9-5b771a8d7d03.js'); ?>

<?php /**PATH /var/www/projects/gogps/gpscontrol/resources/views/includes/app-vue.blade.php ENDPATH**/ ?>