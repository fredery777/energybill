<!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
<!--    <?php echo Html::script ('assets/plugins/jquery/jquery.min.js'); ?>

     Bootstrap tether Core JavaScript 
    <?php echo Html::script ('assets/plugins/bootstrap/js/popper.min.js'); ?>

    <?php echo Html::script ('assets/plugins/bootstrap/js/bootstrap.min.js'); ?>

     slimscrollbar scrollbar JavaScript 
    <?php echo Html::script ('js/jquery.slimscroll.js'); ?>

    Wave Effects 
     <?php echo Html::script ('js/waves.js'); ?>

    Menu sidebar 
    <?php echo Html::script ('js/sidebarmenu.js'); ?>

    stickey kit 
    <?php echo Html::script ('assets/plugins/sticky-kit-master/dist/sticky-kit.min.js'); ?>

    Custom JavaScript 
    <?php echo Html::script ('js/custom.min.js'); ?>

    <?php echo Html::script ('assets/plugins/toast-master/js/jquery.toast.js'); ?>

    <?php echo Html::script ('assets/plugins/sweetalert2/dist/sweetalert2.all.min.js'); ?>


     ============================================================== 
     Style switcher 
     ============================================================== 
    <?php echo Html::script ('assets/plugins/styleswitcher/jQuery.style.switcher.js'); ?>

     ============================================================== 
     Redirect 
     ============================================================== 
    <?php echo Html::script ('js/jquery.redirect.js'); ?>

     ============================================================== 
     Data Table 
     ============================================================== 
    <?php echo Html::script ('js/datatables.min.js'); ?>

     ============================================================== 
     Calendar 
     ============================================================== 
   <?php echo Html::script ('js/jquery_ui_timepicker_addon.js'); ?>

    <?php echo Html::script ('js/jquery_ui_sliderAccess.js'); ?>


    <?php echo Html::script ('js/chosen.jquery.js'); ?>-->
    
     <!-- ============================================================== -->
    <!-- Functions js -->
    <!-- ============================================================== -->
<?php echo Html::script ('assets/plugins/sweetalert2/dist/sweetalert2.all.min.js'); ?>

<?php echo Html::script ('assets/plugins/moment/moment.min.js'); ?>

<?php echo Html::script ('js/functions.js'); ?>

<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo env('KEY_GOOGLE_MAP', 'forge'); ?>&language=es-es"></script>



<script type="text/javascript">
    window.onload = function () {
     $("[data-widget-modal='remove']").click(function() {
    //Find the box parent........
    var box = $(this).parents(".box").first();
    $(box).hide(); 
});

 $("[data-widget-modal='collapse']").click(function() {
    //Find the box parent........
    var box = $(this).parents(".box").first();
    //Find the body and the footer
    var bf = box.find(".box-body, .box-footer");
    if (!$(this).children().hasClass("fa-plus")) {
        $(this).children(".fa-minus").removeClass("fa-minus").addClass("fa-plus");
       bf.slideUp();
    } else {
        //Convert plus into minus
        $(this).children(".fa-plus").removeClass("fa-plus").addClass("fa-minus");
       bf.slideDown();
    }
});

     drag('.div-modal');
     assignResetFrm();
     timeCalendar();
      $(".chzn-select").chosen({ width: "100%",no_results_text: "No existen registros..",placeholder_text_multiple: "..Seleccione una o varias.."});
      
        $('html,body').on('focus',".chzn-select", function(){
            $(".chzn-select").chosen({ width: "100%",no_results_text: "No existen registros..",placeholder_text_multiple: "..Seleccione una o varias.."});
            $('.chzn-select').trigger("chosen:updated");
    
       });
    $('.multifield').multifield();
 
 
 /**
       * The CenterControl adds a control to the map that recenters the map on
       * Chicago.
       * This constructor takes the control DIV as an argument.
       * @constructor
       */
      function CenterControl(controlDiv, map) {

        // Set CSS for the control border.
        var controlUI = document.createElement('div');
        controlUI.style.backgroundColor = '#fff';
        controlUI.style.border = '2px solid #fff';
        controlUI.style.borderRadius = '3px';
        controlUI.style.boxShadow = '0 2px 6px rgba(0,0,0,.3)';
        controlUI.style.cursor = 'pointer';
        controlUI.style.marginBottom = '22px';
        controlDiv.appendChild(controlUI);

        var html='';
        /*html=html+'<div class="navbar navbar-expand-md">';
        html=html+'<div class="navbar-collapse">';
            html=html+'<ul class="navbar-nav mr-auto mt-md-0 ">';
                html=html+'<li class="nav-item dropdown mega-dropdown">';
                    html=html+'<a class="nav-link text-muted waves-effect waves-dark" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-search"></i></a>';
                    html=html+'<div class="dropdown-menu animated bounceInDown">';
                        html=html+'<ul class="mega-dropdown-menu row">';
                        html=html+' <li class="col-md-12">';
                                    html=html+'<h4>CONTACT US</h4>';
                        html=html+'</li>';
                        html=html+'</ul>';
                    html=html+'</div>';
               html=html+'</li>';
               
                html=html+'<li class="nav-item dropdown mega-dropdown">';
                    html=html+'<a class="nav-link text-muted waves-effect waves-dark" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-traffic-light"></i></a>';
                    html=html+'<div class="dropdown-menu animated bounceInDown">';
                        html=html+'<ul class="mega-dropdown-menu row">';
                        html=html+' <li class="col-md-12">';
                                    html=html+'<h4>CONTACT UStt</h4>';
                        html=html+'</li>';
                        html=html+'</ul>';
                    html=html+'</div>';
               html=html+'</li>';
               
                html=html+'<li class="nav-item dropdown mega-dropdown">';
                    html=html+'<a class="nav-link text-muted waves-effect waves-dark" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-road"></i></a>';
                    html=html+'<div class="dropdown-menu animated bounceInDown">';
                        html=html+'<ul class="mega-dropdown-menu row">';
                        html=html+' <li class="col-md-12">';
                                    html=html+'<h4>CONTACT UStt</h4>';
                        html=html+'</li>';
                        html=html+'</ul>';
                    html=html+'</div>';
               html=html+'</li>';
               
            html=html+'</ul>';
        html=html+'</div>';
        html=html+'</div>';
        */
        html=html+'<div class="row">';
        html=html+'<div class="col-md-12">';
        html=html+' <div class="button-group">';
        html=html+' <button type="button" title="Buscar" class="waves-effect waves-light btn-info btn-circle btn-sm" id="btnBusq""> <i class="fa fa-search"></i></button>';
        html=html+' <button type="button" class="waves-effect waves-light btn-info btn-circle btn-sm" id="btnExport"><i class="fas fa-traffic-light" ></i></button>';
        html=html+' <button type="button" class="waves-effect waves-light btn-info btn-circle btn-sm" id="btnExport"><i class="fas fa-road" ></i></button>';
        html=html+' <button type="button" class="waves-effect waves-light btn-info btn-circle btn-sm" id="btnExport"><i class="far fa-bell" ></i></button>';
        html=html+' <button type="button" class="waves-effect waves-light btn-info btn-circle btn-sm" id="btnExport"><i class="fas fa-draw-polygon" ></i></button>';
        html=html+' <button type="button" class="waves-effect waves-light btn-info btn-circle btn-sm" id="btnExport"><i class="fas fa-download"></i></button>';
        html=html+'</div>';  
        html=html+'</div>';
        html=html+'</div>';
    
    
    //html=html+'<span class="mytooltip tooltip-effect-1"><span class="tooltip-item">Euclid</span> <span class="tooltip-content clearfix"><img src="https://wrappixel.com/demos/admin-templates/monster-admin/assets/images/tooltip/Euclid.png" alt="euclid"><span class="tooltip-text">Also known as Euclid of andria, was a Greek mathematician, often referred.</span> </span></span>'

        // Set CSS for the control interior.
        var controlText = document.createElement('div');
        controlText.style.color = 'rgb(25,25,25)';
        controlText.style.fontFamily = 'Roboto,Arial,sans-serif';
        controlText.style.fontSize = '16px';
        controlText.style.lineHeight = '38px';
        controlText.style.paddingLeft = '5px';
        controlText.style.paddingRight = '5px';
        controlText.style.width = '100%';
        controlText.innerHTML = html;
        controlUI.appendChild(controlText);

        // Setup the click event listeners: simply set the map to Chicago.
        /*controlUI.addEventListener('click', function() {
          map.setCenter(chicago);
        });*/

      }
  var map;
      function initMap() {
         var map = new google.maps.Map(document.getElementById('map'), 
         {
            zoom: 12,
            center: {lat: -28.643387, lng: 153.612224},
            mapTypeControl: false,
            mapTypeControlOptions: {
                style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
                position: google.maps.ControlPosition.TOP_CENTER
            },
            zoomControl: true,
            zoomControlOptions: {
                position: google.maps.ControlPosition.LEFT_TOP
            },
            scaleControl: true,
            streetViewControl: false,
            fullscreenControl: true
          });
        
        /*map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: -34.397, lng: 150.644},
          zoom: 8,
           disableDefaultUI: true,
           mapTypeControl: true,
            mapTypeControlOptions: {
              style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
              mapTypeIds: ['roadmap', 'terrain']
            }
        });*/
        

        // Create the DIV to hold the control and call the CenterControl()
        // constructor passing in this DIV.
        var centerControlDiv = document.createElement('div');
        var centerControl = new CenterControl(centerControlDiv, map);

        centerControlDiv.index = 1;
        map.controls[google.maps.ControlPosition.BOTTOM_CENTER].push(centerControlDiv);
  

      }
    //  initMap();
 
 };
 
     
 </script><?php /**PATH /var/www/projects/gogps/gpscontrol/resources/views/includes/footer-backend.blade.php ENDPATH**/ ?>