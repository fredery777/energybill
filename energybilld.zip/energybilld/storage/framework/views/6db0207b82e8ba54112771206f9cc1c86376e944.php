<!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
<!--    <?php echo Html::script ('assets/plugins/jquery/jquery.min.js'); ?>

     Bootstrap tether Core JavaScript 
    <?php echo Html::script ('assets/plugins/bootstrap/js/popper.min.js'); ?>

    <?php echo Html::script ('assets/plugins/bootstrap/js/bootstrap.min.js'); ?>

     slimscrollbar scrollbar JavaScript 
    <?php echo Html::script ('js/jquery.slimscroll.js'); ?>

    Wave Effects 
     <?php echo Html::script ('js/waves.js'); ?>

    Menu sidebar 
    <?php echo Html::script ('js/sidebarmenu.js'); ?>

    stickey kit 
    <?php echo Html::script ('assets/plugins/sticky-kit-master/dist/sticky-kit.min.js'); ?>

    Custom JavaScript 
    <?php echo Html::script ('js/custom.min.js'); ?>

    <?php echo Html::script ('assets/plugins/toast-master/js/jquery.toast.js'); ?>

    <?php echo Html::script ('assets/plugins/sweetalert2/dist/sweetalert2.all.min.js'); ?>


     ============================================================== 
     Style switcher 
     ============================================================== 
    <?php echo Html::script ('assets/plugins/styleswitcher/jQuery.style.switcher.js'); ?>

     ============================================================== 
     Redirect 
     ============================================================== 
    <?php echo Html::script ('js/jquery.redirect.js'); ?>

     ============================================================== 
     Data Table 
     ============================================================== 
    <?php echo Html::script ('js/datatables.min.js'); ?>

     ============================================================== 
     Calendar 
     ============================================================== 
   <?php echo Html::script ('js/jquery_ui_timepicker_addon.js'); ?>

    <?php echo Html::script ('js/jquery_ui_sliderAccess.js'); ?>


    <?php echo Html::script ('js/chosen.jquery.js'); ?>-->
    
     <!-- ============================================================== -->
    <!-- Functions js -->
    <!-- ============================================================== -->
<?php echo Html::script ('assets/plugins/sweetalert2/dist/sweetalert2.all.min.js'); ?>

<?php echo Html::script ('js/functions.js'); ?>




$("[data-widget-modal='remove']").click(function() {
    //Find the box parent........
    var box = $(this).parents(".box").first();
    $(box).hide(); 
});

<script type="text/javascript">
    window.onload = function () {
     $("[data-widget-modal='remove']").click(function() {
    //Find the box parent........
    var box = $(this).parents(".box").first();
    $(box).hide(); 
});

 $("[data-widget-modal='collapse']").click(function() {
    //Find the box parent........
    var box = $(this).parents(".box").first();
    //Find the body and the footer
    var bf = box.find(".box-body, .box-footer");
    if (!$(this).children().hasClass("fa-plus")) {
        $(this).children(".fa-minus").removeClass("fa-minus").addClass("fa-plus");
       bf.slideUp();
    } else {
        //Convert plus into minus
        $(this).children(".fa-plus").removeClass("fa-plus").addClass("fa-minus");
       bf.slideDown();
    }
});

     drag('.div-modal');
     assignResetFrm();

 };
 </script><?php /**PATH /var/www/laravel/gogps/settings/resources/views/includes/footer-backend.blade.php ENDPATH**/ ?>