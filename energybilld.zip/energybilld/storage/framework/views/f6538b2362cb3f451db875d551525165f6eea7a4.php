<?php echo Html::script ('js/vue/app_vue_4cc8b46c-3e37-474a-a891-d5e91733cf0c.js'); ?>

<?php /**PATH /var/www/laravel/gogps/settings/resources/views/includes/app-vue.blade.php ENDPATH**/ ?>