  
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer">
    <?php echo Config::get('constants.options.copyright'); ?> <?php echo env('COMPANY_NAME', 'forge'); ?>  <?php echo Config::get('constants.options.recommendation'); ?> 
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== --><?php /**PATH /var/www/projects/gogps/gpscontrol/resources/views/includes/footer.blade.php ENDPATH**/ ?>