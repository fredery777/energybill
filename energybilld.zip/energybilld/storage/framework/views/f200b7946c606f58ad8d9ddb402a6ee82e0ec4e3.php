
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo csrf_token(); ?>" /> 
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo env('COMPANY_NAME', 'forge'); ?>">
    <meta name="author" content="Fredy Herrera">
    <!-- Bootstrap Core CSS -->
    <?php echo Html::style('assets/plugins/bootstrap/css/bootstrap.min.css'); ?>

    <!-- Custom CSS -->
   <?php echo Html::style('css/style.css'); ?>

    <!-- You can change the theme colors from here -->
     <?php echo Html::style('css/colors/blue.css'); ?>

      <!--Notifications -->
     <?php echo Html::style('assets/plugins/toast-master/css/jquery.toast.css'); ?>

      <!--alerts CSS -->
     <?php echo Html::style('assets/plugins/sweetalert2/dist/sweetalert2.min.css'); ?>


 <!-- leaflet -->
    <?php echo Html::style('assets/plugins/leaflet/css/leaflet.css'); ?>


       <!-- Date picker plugins css -->
     <?php echo Html::style('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css'); ?>

     
      <!-- Daterange picker plugins css -->
     <?php echo Html::style('assets/plugins/timepicker/bootstrap-timepicker.min.css'); ?>

     <?php echo Html::style('assets/plugins/daterangepicker/daterangepicker.css'); ?>

     
      <!--Auto complete -->
     <?php echo Html::style('css/jquery-ui.css'); ?>

     
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<?php /**PATH /var/www/projects/energybill/resources/views/includes/head-backend.blade.php ENDPATH**/ ?>