<?php echo Html::script ('js/vue/app_vue_eeac05df-ca4d-420e-acba-7c53a2ddf1ce.js'); ?>

<?php /**PATH /var/www/projects/bvstudio/resources/views/includes/app-vue.blade.php ENDPATH**/ ?>