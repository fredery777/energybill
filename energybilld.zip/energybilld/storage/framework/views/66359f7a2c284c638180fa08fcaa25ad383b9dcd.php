<?php echo Html::script ('js/vue/app_vue_2e519476-97e7-415f-bf62-3d899d309004.js'); ?>

<?php /**PATH /var/www/proyects/gogps/settings/resources/views/includes/app-vue.blade.php ENDPATH**/ ?>