
    
     <!-- ============================================================== -->
    <!-- Functions js -->
    <!-- ============================================================== -->

<?php echo Html::script ('assets/plugins/sweetalert2/dist/sweetalert2.all.min.js'); ?>

<?php echo Html::script ('assets/plugins/moment/moment.min.js'); ?>

<?php echo Html::script ('js/functions.js'); ?>


<script type="text/javascript">
    window.onload = function () {
     $("[data-widget-modal='remove']").click(function() {
    //Find the box parent........
    var box = $(this).parents(".box").first();
    $(box).hide(); 
});

 $("[data-widget-modal='collapse']").click(function() {
    //Find the box parent........
    var box = $(this).parents(".box").first();
    //Find the body and the footer
    var bf = box.find(".box-body, .box-footer");
    if (!$(this).children().hasClass("fa-plus")) {
        $(this).children(".fa-minus").removeClass("fa-minus").addClass("fa-plus");
       bf.slideUp();
    } else {
        //Convert plus into minus
        $(this).children(".fa-plus").removeClass("fa-plus").addClass("fa-minus");
       bf.slideDown();
    }
});

     drag('.div-modal');
     assignResetFrm();
    
 
 };
 
     
 </script><?php /**PATH /var/www/projects/energybill/resources/views/includes/footer-backend.blade.php ENDPATH**/ ?>