<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="_token" content="<?php echo csrf_token(); ?>" /> 
        <title>Modulos-<?php echo env('COMPANY_NAME', 'forge'); ?></title>
        <meta content="width=device-width, initial-scale=1" name="viewport">
        <?php echo $__env->yieldContent('head'); ?>
        <?php echo $__env->make('includes.head-backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>       
    </head>
    <!--Cabecera-->  
    <body class="fix-header card-no-border fix-sidebar">
         <!-- ============================================================== -->
         <!-- Preloader - style you can find in spinners.css -->
         <!-- ============================================================== -->
        <div class="preloader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
        </div>
        
        <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>       
        <div class="page-wrapper" style="background-image:url(assets/images/background/backpagewrapper.jpg);">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid" >
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row" >
                    <!-- Column -->
                    <?php $__currentLoopData = $arr_module_ppal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module_ppal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6" style="cursor: pointer" onclick="redirectModule('<?php echo $module_ppal->url; ?>')" >
                           <div class="card">
                               <div class="card-body">
                                   <!-- Row -->
                                   <div class="row">
                                       <div class="col-3"><span class="display-5"><i class="<?php echo e($module_ppal->css_icon); ?>"></i></span></div>
                                       <div class="col-9 align-self-center text-left  pl-0">
                                             <h2><?php echo e($module_ppal->module_ppal_name); ?></h2> 
                                       </div>
                                   </div>
                               </div>
                           </div>
                       </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                
                
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
           <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== --> 
        <!-- REQUIRED JS SCRIPTS -->
        <?php echo $__env->make('includes.footer-module', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
        <?php echo $__env->yieldContent('funcionesScript'); ?>   
<script type="text/javascript">

    var arrJson=<?php echo $json_data; ?>;
    redirectM(arrJson);

    function redirectM(arrJson)
    {
	 
        var data=arrJson; 
		
        if(data.count == 1)
        {
            redirectModule(data.data_modulo[0].url);
        }
		else if(data.count == 0)
		{
            alert("No posee modulos activos para su perfil !!!");
        }
    }

    function redirectModule(urlModule)
    {
       
        var currentLocation = window.location.href;
        var urlRedirectModule = ''+currentLocation+'module';
       

        $.post(urlRedirectModule, {
            'send': 'OK'
        }
        )
                .done(function (jsonData) {

                    loadModule(jsonData, urlModule);
                })
                .fail(function () {
                    alert("error");
                });
    }

    function loadModule(jsonData, urlModule)
    {
        $.redirect(urlModule, {'id': jsonData.id}, 'POST');
    }
</script>
    </body>
</html>
<?php /**PATH /var/www/projects/energybill/resources/views/modules.blade.php ENDPATH**/ ?>