<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li> 
      <?php if(empty($item->url())): ?>
          <a class="has-arrow" href="#" aria-expanded="false"><?php echo $item->title; ?> </span> </a>
      <?php else: ?>
           <li><a href="<?php echo $item->url(); ?>"><?php echo $item->title; ?></a></li>
      <?php endif; ?>
 
      <?php if($item->hasChildren()): ?>
        <ul aria-expanded="false" class="collapse">
           <?php echo $__env->make('layouts.custom-menu-h-items', array('items' => $item->children()), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </ul>
       <?php endif; ?>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /var/www/proyects/gogps/gpscontrol/resources/views/layouts/custom-menu-h-items.blade.php ENDPATH**/ ?>