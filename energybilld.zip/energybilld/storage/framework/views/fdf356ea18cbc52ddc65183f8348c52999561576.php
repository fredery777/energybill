  <!-- ============================================================== -->
<!-- Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li>
                    <a href="/homepage" aria-expanded="false"><i class="fa fa-home"></i><span class="hide-menu">Home</span></a>
                </li>  
                <?php echo $__env->make('layouts.custom-menu-h-items', array('items' => $MyNavBarH->roots()), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>
<!-- ============================================================== -->
<!-- End Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== --><?php /**PATH /var/www/laravel/gogps/settings/resources/views/layouts/custom-menu-h.blade.php ENDPATH**/ ?>