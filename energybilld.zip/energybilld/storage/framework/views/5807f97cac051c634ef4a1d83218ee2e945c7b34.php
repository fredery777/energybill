<?php echo Html::script ('js/vue/app_vue_beb61090-69b9-45b0-a772-c7c01028c9a8.js'); ?>

<?php /**PATH /var/www/proyects/gogps/gpscontrol/resources/views/includes/app-vue.blade.php ENDPATH**/ ?>