<?php echo Html::script ('js/vue/app_vue_86b9c047-b459-4588-bebb-0c5d721ac994.js'); ?>

<?php /**PATH /var/www/projects/energybill/resources/views/includes/app-vue.blade.php ENDPATH**/ ?>