
    
     <!-- ============================================================== -->
    <!-- Functions js -->
    <!-- ============================================================== -->
 <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <?php echo Html::script ('assets/plugins/jquery/jquery.min.js'); ?>

    <!-- Bootstrap tether Core JavaScript -->
    <?php echo Html::script ('assets/plugins/bootstrap/js/popper.min.js'); ?>

    <?php echo Html::script ('assets/plugins/bootstrap/js/bootstrap.min.js'); ?>

    <!-- slimscrollbar scrollbar JavaScript -->
    <?php echo Html::script ('js/jquery.slimscroll.js'); ?>

    <!--Wave Effects -->
     <?php echo Html::script ('js/waves.js'); ?>

    <!--Menu sidebar -->
    <?php echo Html::script ('js/sidebarmenu.js'); ?>

    <!--stickey kit -->
    <?php echo Html::script ('assets/plugins/sticky-kit-master/dist/sticky-kit.min.js'); ?>

    <!--Custom JavaScript -->
    <?php echo Html::script ('js/custom.min.js'); ?>

    <!-- ============================================================== -->
    <!-- Style switcher -->
    <!-- ============================================================== -->
    <?php echo Html::script ('assets/plugins/styleswitcher/jQuery.style.switcher.js'); ?>

    <!-- ============================================================== -->
    <!-- Redirect -->
    <!-- ============================================================== -->
    <?php echo Html::script ('js/jquery.redirect.js'); ?>

    
    
    


 
     
 </script><?php /**PATH /var/www/projects/energybill/resources/views/includes/footer-module.blade.php ENDPATH**/ ?>