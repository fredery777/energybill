<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model as Model;
use App\Models\clsBd;


class clsUtil extends Model
{    

    protected $bd;
    function __construct(clsBd $bd)
    {
        $this->bd                   = $bd;
    }
    
    /**
     * Function that removes extraneous characters
     * @param String $val
     * @param int $cant_characters
     * @return String
     **/
    
    function data_clean($val, $count_characters = '') 
    {
        if (!empty($count_characters))
            $val = addslashes(trim(substr($val, 0, $count_characters)));
        else
            $val = addslashes(trim(strtoupper($val)));
								
        $val = str_replace("'", "", $val);
        $val = str_replace("\"", "", $val);
        $val = str_replace("(", "", $val);
        $val = str_replace(")", "", $val);
        $val = str_replace("&", "", $val);
        $val = str_replace("|", "", $val);
        $val = str_replace("<", "", $val);
        $val = str_replace(">", "", $val);
        $val = str_replace("--", "", $val);
        $val = str_replace("�", "�", $val);
        $val = str_replace("�", "�", $val);
        $val = str_replace("�", "a", $val);
        $val = str_replace("�", "A", $val);
        $val = str_replace("�", "a", $val);
        $val = str_replace("�", "A", $val);
        $val = str_replace("�", "e", $val);
        $val = str_replace("�", "E", $val);
        $val = str_replace("�", "i", $val);
        $val = str_replace("�", "I", $val);
        $val = str_replace("�", "o", $val);
        $val = str_replace("�", "O", $val);
        $val = str_replace("�", "u", $val);
        $val = str_replace("�", "U", $val);
        $val = str_replace('"', "", $val);
        $val = preg_replace("[\n|\r|\n\r]", " ", $val);
								
        return $val;
    }
    /**
     * Add quotes a string
     * @param type $string
     * @param type $char
     * @return type
     * 
     */
    function str_wrap($string = '', $char = "'") {
        return str_pad($string, strlen($string) + 2, $char, STR_PAD_BOTH);
    }

  /**
   * 
   * @return date
   * Returns the current date
   */
    function now_date() {
        return date('Y-m-d H:i:s');
    }
    
    function allowed_module($arrPar) 
    {          
         $arr_modules= array();
        //if(\Auth::check())
        //{
             $arr_in = [
                    'module_ppal_id' =>0
                 ];
            $arrData['name']='settings.pl_allowed_module';
          
            $arrData['param']=[json_encode($arr_in)];
            $arrData['return']=[
                'count INTEGER', 
                'module_ppal_id INTEGER', 
                'module_ppal_name TEXT', 
                'css_icon TEXT',
                'url TEXT'
            ];
           // $arrData['toSql']=true;
            $arr_modules = $this->bd->execute_procedure($arrData); 
        //}
        return $arr_modules;
    }
    
}