<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model as Model;
use DB;

class clsBd extends Model
{   
    /**
     * 
     * @param type $arrData
     * @return type
     * build the sql in the bd
     */
    function make_select($arrData)
    {  

        $arrSelect=( (isset($arrData['fillable'])&&!empty($arrData['fillable'])))?$arrData['fillable']:array();
        $arrSelect=(isset($arrData['model']))?$arrData['model']->fillable:$arrSelect;
        if(isset($arrData['fillableMan']))
        {
            $arrSelect = $this->select_manually($arrData['fillableMan'],$arrSelect);
        } 
        if(isset($arrData['fillableCon']))
        {
            $arrSelect = $this->select_concat($arrData['fillableCon'],$arrSelect);
        }        
        
       
        return $arrSelect;
    }
    /**
     * 
     * @param type $arrConcat
     * @param type $arrSelect
     * @return type
     * 
     */
    function select_concat($arrConcat, $arrSelect)
    {        
        if(is_array($arrConcat)){
            foreach ($arrConcat as $concat)
            {          
                $concat[0] = str_replace('||',"'",$concat[0]);
                $select = DB::raw('CONCAT('.$concat[0].')'.(isset($concat[1]) ? ' AS '.$concat[1] : ' '));
                array_push($arrSelect, $select);
            }
        }        
        return $arrSelect;
    }
    /**
     * 
     * @param type $arrMan
     * @param type $arrSelect
     * @return type
     */
    function select_manually($arrMan, $arrSelect)
    {        
        if(is_array($arrMan)){
            foreach ($arrMan as $dataM)
            {                      
                $select = DB::raw($dataM);
                array_push($arrSelect, $select);
            }
        }        
        return $arrSelect;
    }
    /**
     * 
     * @param type $arrData
     * @return type
     * generate the query to the bd
     */
    function consult($arrData)
    {        
        $table=(isset($arrData['table'])&&!empty($arrData['table']))?$arrData['table']:$arrData['model']->table;
        $return = DB::table($table);
        
      // If you apply special functions        
        $arrFillable=$this->make_select($arrData);   
        
        $return->select($arrFillable);            
       // Travel Filters
        if(isset($arrData['filter']) AND !empty($arrData['filter'])){
            foreach($arrData['filter'] as $where)
            {
                if(is_array($where))
                {
                  // If the filter is a subquery, arm the IN ()
                    if(isset($where['group']))
                    {
                        $type=(isset($where['group']['type']) ? $where['group']['type'] : 'where');
                        $return->$type(function ($query) use($where) { 
                            foreach($where['data'] as $where_group)
                            {                                
                                
                                    $filter = $this->consult_filter($where_group);
                                    $query->whereRaw($filter,array(),(isset($where_group['type']) ? $where_group['type'] : 'AND'));
                                
                            }
                        });
                    }
                    else{
                        $filter = $this->consult_filter($where);
                        $return->whereRaw($filter,array(),(isset($where['type']) ? $where['type'] : 'AND'));                                                
                    }
                }
                else{
                    $return->whereRaw($where);
                }
            }             
        }
        // travel Joins
        if(isset($arrData['join']) AND !empty($arrData['join'])){
            foreach($arrData['join'] as $join)
            {
                $type=(!empty($join['type'])?$join['type']:'leftJoin');
                $return->$type($join['table'],function($query) use($join){
                    $query->on($join['fieldA'],(isset($join['operator']) ? $join['operator'] : '='),$join['fieldB']);
                    //Si tiene filtro el join Array
                    if(isset($join['filter']) AND is_array(isset($join['filter']))){
                        foreach($join['filter'] as $where_join)
                        {
                            if(is_int($where_join['value']))
                                $where_join['value']="'{$where_join['value']}'";
                            $query->where($where_join['field'],(isset($where_join['operator']) ? $where_join['operator'] : ''),$where_join['value']);
                        }
                    }                
                });
            }            
        }
        //travel field GroupBy
        if(isset($arrData['groupBy']) AND !empty($arrData['groupBy'])){            
            foreach($arrData['groupBy'] as $groupBy)
            {
                $return->groupBy($groupBy);
            }                            
        }
        // field OrderBy
        if(isset($arrData['orderBy']) AND !empty($arrData['orderBy'])){            
            foreach($arrData['orderBy'] as $orderBy)
            {
                $field = $this->field_build($orderBy['field']);
                $return->orderBy(DB::raw($field),(isset($orderBy['type'])? $orderBy['type'] : 'ASC'));
            }                            
        }
        //Limit
        if(isset($arrData['limit']) AND !empty($arrData['limit'])){            
            $return->take($arrData['limit']);
        }
 
        //Retunr type
        if(isset($arrData['toSql'])){
            return $return->toSql();
        }elseif (isset($arrData['get'])){
            return $return->get();
        }else{
            return $return;
        }
    }
    /**
     * 
     * @param type $where
     * @return type
     * filter query
     */
    function consult_filter($where)
    {
            if(is_int($where['value']))
                $where['value']="'{$where['value']}'";
                            
            $field = $this->field_build($where['field']);        
            return $field.' '.(isset($where['operator']) ? $where['operator'] : '=').' '.$where['value'];
        
    }
    /**
     * 
     * @param type $field
     * @return type
     */
    function field_build($field)
    {
        return $field;
    }
    
   
    
   /**
    * 
    * @param type $arrData
    * @return boolean
    * method that determines whether or not there are records with characteristics in a table
    */
    function check_records($arrData) 
    {
        $row = $this->records_num($arrData);        
        return (($row > 0) ? true : false);
    }
   /**
    * 
    * @param type $arrData
    * @return integer
    *  //Method returns the number of records in the query
    */
    function records_num($arrData) 
    {
        $pos='COUNT(*)';
        $arrEnv['fillable'] =[DB::raw($pos)];     
        $row = $this->special_query($arrData, $arrEnv);  
        $count=(isset($row[0]->count))? $row[0]->count:$row[0]->$pos;
        return (!empty($count) ? $count : 0);        
    }
    /**
     * 
     * @param type $arrData
     * @param type $arrEnv
     * @return type
     */
    function special_query($arrData, $arrEnv)
    {
        $arrEnv['get'] =true;
        $arrEnv['table'] =(isset($arrData['table'])&&!empty($arrData['table']))? $arrData['table'] : $arrData['model']->table;        
        if(isset($arrData['filter']) AND !empty($arrData['filter']))
            $arrEnv['filter'] = $arrData['filter'];
        if(isset($arrData['join']) AND !empty($arrData['join']))
            $arrEnv['join'] = $arrData['join'];
        if(isset($arrData['groupBy']) AND !empty($arrData['groupBy']))
            $arrEnv['groupBy'] = $arrData['groupBy'];        
        if(isset($arrData['toSql']) AND !empty($arrData['toSql']))
            $arrEnv['toSql'] = $arrData['toSql']; 
        
       
        return $this->consult($arrEnv);             
    }
    
    /**
     * 
     * @param type $arrData
     * @return type
     */
    function execute_procedure($arrData)
    {
        $param ='';
        $return ='';
        
        if(isset($arrData['return']))
        {
            foreach($arrData['return'] as $returns)
            {
                $return .= (!empty($return) ? ' , '.$returns : ' AS ('.$returns);
            }            
            $return .=')';            
        }
        if(isset($arrData['param']))
        {
            foreach($arrData['param'] as $params)
            {
                $param .= (!empty($param) ? " , '$params'" : "'$params'");
            }            
        } 
        
        if(isset($arrData['toSql']))
		 {
	       $data = $this->name_procedure($arrData).' ('.$param.') '.$return;
                
		 }
		 else
		 {
	        $data = DB::select($this->name_procedure($arrData).' ('.$param.') '.$return);
		 }
		 
        return $data;
    }
    function name_procedure($arrData)
    {
        $select =(isset($arrData['return']) ? 'SELECT * FROM '.$arrData['name'] : 'SELECT '.$arrData['name']);
        return $select;
    }
    
}