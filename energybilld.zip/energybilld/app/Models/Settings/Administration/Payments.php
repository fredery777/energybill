<?php
namespace App\Models\Settings\Administration;
use App\Models\BaseModel;

class Payments extends BaseModel
{
    public $table = "settings.payments";
    public $primaryKey = "id";
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $fillable = [
        'bill_id',
        'created_at',
        'updated_at',
        'register_status_id'
       
    ];
       public static $rules = [
        
    ];
    public static $fields = [
       
    ];
}
