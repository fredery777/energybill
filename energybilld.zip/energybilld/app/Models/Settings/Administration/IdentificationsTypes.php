<?php
namespace App\Models\Settings\Administration;
use App\Models\BaseModel;

class IdentificationsTypes extends BaseModel
{
    public $table = "settings.identifications_types";
    public $primaryKey = "id";
    public $page_id = 20;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $fillable = [
        'identification_type_name',
        'row_lock'
       
    ];
    
     /**
     * Validation rules
     *
     * @var array
     */
     public static $rules = [];

     public static $fields = [];
}
