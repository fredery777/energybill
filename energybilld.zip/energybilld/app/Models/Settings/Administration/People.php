<?php

namespace App\Models\Settings\Administration;
use App\Models\BaseModel;

class People extends BaseModel
{
    public $table = "settings.people";
    public $primaryKey = "id";

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id',
        'identification_number',
        'verification_digit', 
        'person_status_id', 
        'person_type_id', 
        'identification_type_id', 
        'first_name',
        'second_name',
        'first_last_name',
        'second_last_name',
        'birthdate',
        'address',
        'cell_phone',
        'email',
        'created_at',
        'updated_at',
        'register_status_id',
        'person_gender_id',
           ];
    
    public static $rules = [
        'txtIdentificationNumber' => 'required|Min:4|unique:settings.people,identification_number',
        'optPersonType' => 'required',
        'optIdentificationType' => 'required'
    ];
    public static $fields = [
        'txtIdentificationNumber' => 'Nro Identificación',
        'optPersonType' => 'Tipo',
        'optIdentificationType' => 'Tipo Identificación'
    ];
    
     public function getFullNameAttribute()
     {
         $name= $this->first_name;
         $name.= (!empty($this->second_name) ? ' ' : '').$this->second_name;
         $name.= (!empty($this->first_last_name) ? ' ' : '').$this->first_last_name;
         $name.= (!empty($this->second_last_name) ? ' ' : '').$this->second_last_name;
         return $name;
     }
    
    public function search_filter($term){
        $filtro = [
            [
                'group'=>true,
                'data'=>[
                   ['field'=>'first_name','value'=>"'%".strtoupper($term)."%'",'operator'=>'LIKE'],
                   ['field'=>'second_name','value'=>"'%".strtoupper($term)."%'",'operator'=>'LIKE', 'type'=>'OR'],
                   ['field'=>'first_last_name','value'=>"'%".strtoupper($term)."%'",'operator'=>'LIKE', 'type'=>'OR'],
                   ['field'=>'second_last_name','value'=>"'%".strtoupper($term)."%'",'operator'=>'LIKE', 'type'=>'OR'],
                   ['field'=>'identification_number','value'=>"'".strtoupper($term)."%'",'operator'=>'LIKE', 'type'=>'OR'],
                   ['field'=>"CONCAT(first_name||' ',second_name||' ',first_last_name||' ',second_last_name)::TEXT",'value'=>"'%".strtoupper($term)."%'",'operator'=>'LIKE', 'type'=>'OR'],
                ],
                
            ],
            ['field'=>'person_status_id','value'=>"1",'operator'=>'=', 'type'=>'AND'],
                ['field'=>'register_status_id','value'=>"1",'operator'=>'=', 'type'=>'AND']
        ];
        return ['filter'=>$filtro,'fillable'=>['identification_number','first_name','second_name','first_last_name','second_last_name','id AS id_label'],'limit'=>'30', 'orderBy'=>[['field'=>'id']]];
    }

}
