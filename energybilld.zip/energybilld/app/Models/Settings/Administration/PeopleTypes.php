<?php
namespace App\Models\Settings\Administration;
use App\Models\BaseModel;

class PeopleTypes extends BaseModel
{
    public $table = "settings.people_types";
    public $primaryKey = "id";

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $fillable = [
        'person_type_name',
        'row_lock'
       
    ];
}
