<?php

namespace App\Models\Settings\Administration;
use App\Models\BaseModel;

class Bills extends BaseModel
{
    public $table = "settings.bills";
    public $primaryKey = "id";

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id',
        'person_id',
        'status_bill_id', 
        'bill_value', 
        'created_at',
        'updated_at',
        'register_status_id',
        'payment_date',
        'kwh'

           ];
    
    public static $rules = [
        
    ];
    public static $fields = [
       
    ];
    
    
    
    public function search_filter($term){
        $filtro = [
            [
                'group'=>true,
                'data'=>[
                   ['field'=>'id::text','value'=>"'%".strtoupper($term)."%'",'operator'=>'LIKE'],
                         ],
                
                
            ],
            ['field'=>'status_bill_id','value'=>"1",'operator'=>'=', 'type'=>'AND'],
                ['field'=>'register_status_id','value'=>"1",'operator'=>'=', 'type'=>'AND']
        ];
        return ['filter'=>$filtro,'fillable'=>['id','id AS id_label'],'limit'=>'30', 'orderBy'=>[['field'=>'id']]];
    }

}
