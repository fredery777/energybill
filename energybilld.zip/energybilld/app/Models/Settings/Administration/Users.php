<?php

namespace App\Models\Settings\Administration;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Users extends Authenticatable
{
    public $table = "users";
    public $primaryKey = "id";

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id',
        'firstname',
        'lastname', 
        'email', 
        'created_at',
        'updated_at'
 
    ];
    
    public static $rules = [
        'txtUserEmail' => 'required|Min:4',
        'txtUserName' => 'required|Min:4',
    ];
    public static $fields = [
        'txtUserEmail' => 'Email',
        'txtUserName' => 'First name',
    ];

   
}
