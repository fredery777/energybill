<?php
namespace App\Models\Settings\Administration;
use App\Models\BaseModel;

class PeopleStatus extends BaseModel
{
    public $table = "settings.people_status";
    public $primaryKey = "id";
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $fillable = [
        'person_status_name',
        'row_lock'
       
    ];
}
