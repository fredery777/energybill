<?php
namespace App\Models\Settings\Administration;
use App\Models\BaseModel;

class StatusBill extends BaseModel
{
    public $table = "settings.status_bill";
    public $primaryKey = "id";
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $fillable = [
        'name_status_bill'
       
    ];
}
