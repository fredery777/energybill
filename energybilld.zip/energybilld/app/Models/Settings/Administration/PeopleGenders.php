<?php
namespace App\Models\Settings\Administration;
use App\Models\BaseModel;

class PeopleGenders extends BaseModel
{
    public $table = "settings.people_genders";
    public $primaryKey = "id";
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $fillable = [
        'gender_name',
        'row_lock'
       
    ];
}
