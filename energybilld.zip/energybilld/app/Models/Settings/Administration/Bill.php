<?php

namespace App\Models\Settings\Administration;
use App\Models\BaseModel;

class Bill extends BaseModel
{
    public $table = "settings.bills";
    public $primaryKey = "id";

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id',
        'person_id',
        'status_bill_id', 
        'bill_value', 
        'created_at',
        'updated_at'

           ];
    
    public static $rules = [
        'txtIdentificationNumber' => 'required|Min:4|unique:settings.people,identification_number',
        'optPersonType' => 'required',
        'optIdentificationType' => 'required'
    ];
    public static $fields = [
        'txtIdentificationNumber' => 'Nro Identificación',
        'optPersonType' => 'Tipo',
        'optIdentificationType' => 'Tipo Identificación'
    ];
    
    
    
    public function search_filter($term){
        $filtro = [
            [
                'group'=>true,
                'data'=>[
                   ['field'=>'first_name','value'=>"'%".strtoupper($term)."%'",'operator'=>'LIKE'],
                   ['field'=>'second_name','value'=>"'%".strtoupper($term)."%'",'operator'=>'LIKE', 'type'=>'OR'],
                   ['field'=>'first_last_name','value'=>"'%".strtoupper($term)."%'",'operator'=>'LIKE', 'type'=>'OR'],
                   ['field'=>'second_last_name','value'=>"'%".strtoupper($term)."%'",'operator'=>'LIKE', 'type'=>'OR'],
                   ['field'=>'identification_number','value'=>"'".strtoupper($term)."%'",'operator'=>'LIKE', 'type'=>'OR'],
                   ['field'=>"CONCAT(first_name||' ',second_name||' ',first_last_name||' ',second_last_name)::TEXT",'value'=>"'%".strtoupper($term)."%'",'operator'=>'LIKE', 'type'=>'OR'],
                ],
                ['field'=>'person_status_id','value'=>"1",'operator'=>'=', 'type'=>'AND'],
                ['field'=>'register_status_id','value'=>"1",'operator'=>'=', 'type'=>'AND']
            ],
        ];
        return ['filter'=>$filtro,'fillable'=>['identification_number','first_name','second_name','first_last_name','second_last_name','id AS id_label'],'limit'=>'30', 'orderBy'=>[['field'=>'id']]];
    }

}
