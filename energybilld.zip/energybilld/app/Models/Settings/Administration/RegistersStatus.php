<?php
namespace App\Models\Settings\Administration;
use App\Models\BaseModel;

class RegistersStatus extends BaseModel
{
    public $table = "settings.registers_status";
    public $primaryKey = "id";
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $fillable = [
        'register_name',
        'row_lock'
       
    ];
}
