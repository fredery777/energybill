<?php

namespace App\Repositories\Settings\Administration;

use App\Models\Settings\Administration\Payments;
use InfyOm\Generator\Common\BaseRepository;

class PaymentsRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        
    ];

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Payments::class;
    }
}
