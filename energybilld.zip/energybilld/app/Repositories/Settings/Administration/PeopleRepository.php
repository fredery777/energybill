<?php

namespace App\Repositories\Settings\Administration;

use App\Models\Settings\Administration\People;
use InfyOm\Generator\Common\BaseRepository;

class PeopleRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        
    ];

    /**
     * Configure the Model
     **/
    public function model()
    {
        return People::class;
    }
}
