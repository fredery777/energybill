<?php

namespace App\Repositories\Settings\Administration;

use App\Models\Settings\Administration\Bills;
use InfyOm\Generator\Common\BaseRepository;

class BillRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        
    ];

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Bills::class;
    }
}
