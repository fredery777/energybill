<?php

namespace App\Exceptions;

use Exception;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Report or log an exception.
     *
     * @param  \Exception  $exception
     * @return void
     */
    public function report(Exception $exception)
    {
        parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Exception  $exception
     * @return \Illuminate\Http\Response
     */
     public function render($request, Exception $e)
    {
        if ($e instanceof \PDOException) {                        
            $code_trans = str_replace('SQLSTATE','',$e->getCode());
            $code_trans = str_replace('[','',$code_trans);
            $code_trans = str_replace(']','',$code_trans);
           

            if(in_array($code_trans,array('P0001')))
            {                
                $msj = explode(':',$e->getMessage());
                $msj = explode('(',$msj[3]);
                $msj = str_replace('CONTEXT','',$msj);
                
                return response()->json([
                    'ErrorBd' => $msj[0],
                    'TlErrorBd' => "System message",
                ]);
            }else{       
                $date = date("Y-m-d H:m:s");
                $code_trans = rand(1,99999999);
 
                $view_log = new Logger('View '.$code_trans);
                $view_log->pushHandler(new StreamHandler(storage_path("logs/pdo.log"), Logger::CRITICAL));
                //$view_log->addEmergency('Cod Dev: '.$code_trans.' '.$e->getMessage());
                
                return response()->json([
                    'ErrorBd' => "Cod :$code_trans, date: $date. Contact support and provide the code for your solution ",
                    'TlErrorBd' => "Whoops !! An error has been detected in the transaction",
                ]);
            }                 
        }else{
            return parent::render($request, $e);
        }
    }
   /*public function render($request, Exception $exception)
    {
        return parent::render($request, $exception);
    }*/
}
