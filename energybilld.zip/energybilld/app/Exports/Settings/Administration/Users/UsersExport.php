<?php

namespace App\Exports\Settings\Administration\Users;

use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Maatwebsite\Excel\Concerns\WithMapping;
use App\Models\clsBd;

class UsersExport implements FromQuery,WithHeadings,ShouldAutoSize,WithTitle,WithEvents,WithMapping
{
    use Exportable;
 
    private $title='Users';
    private $arr_filter;
    
     public function __construct(array $arr_filter)
    {
        $this->arr_filter = $arr_filter;
    }
  
    public function query()
    {
        $bd= new clsBd();
        
        $arrData['table']='users AS U';
        $arrData['fillable'] = array('U.firstname','U.email','U.lastname','U.created_at');
        
        $arrData['orderBy']=[['field'=>'`U`.`created_at`']];
        
        if(!empty($this->arr_filter))
        {
             $arrData['filter'] = $this->arr_filter;
        }
        $users = $bd->consult($arrData);
        return $users;
    }
    
    public function map($users): array
    {
        return [
            $users->firstname,
            $users->lastname,
            $users->email,
            $users->created_at,
        ];
    }
    
    /**
    * @return array
    */
    public function headings(): array
    {
        return [
            ['First name','Last name','Email','	Created at']
        ];
    }
    
     /**
     * @return array
     */
    public function registerEvents(): array
    {
        
        $arr_style=[
                   'font'=>['bold'=>true] 
                ];
        return [
            AfterSheet::class    => function(AfterSheet $event)  use($arr_style) {
                 $event->sheet->getStyle('A1:G1')->applyFromArray($arr_style);
            }
        ];
    }
    
    /**
     * @return string
     */
    public function title(): string
    {
        return $this->title;
    }
}
