<?php

namespace App\Http\Requests\Settings\Administration\Users;

use App\Http\Requests\Request;
use App\Models\Settings\Administration\Users;

class UpdateUsersRequest extends Request
{


   
    /**
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize()
	{
		return true;
	}

	/**
	 * Get the validation rules that apply to the request.
	 *
	 * @return array
	 */
	public function rules(Users $rules)
	{
		return Users::$rules;
	}
	
	/** Get alias from data form 
	 * @return array
	 */
	
	public function attributes()
        {
           return Users::$fields;
        }
	
	/** 
	 * Get id from url  
	 * @return integer
	 */
	private function getSegmentFromEnd($position_from_end = 1) 
        {
		$segments =$this->segments();
		return $segments[sizeof($segments) - $position_from_end];
        }
    
}
