<?php

namespace App\Http\Controllers\Settings\Administration;
use App\Http\Requests\Settings\Administration\Bills\CreateBillsRequest;
use App\Http\Requests\Settings\Administration\Bills\UpdateBillsRequest;
use App\Repositories\Settings\Administration\BillsRepository;
use App\Repositories\Settings\Administration\PeopleRepository;
use App\Http\Controllers\Controller as AppBaseController;
use Illuminate\Http\Request;
use Response;
use App\Models\Settings\Administration\Bills;
use App\Models\Settings\Administration\StatusBill;

use App\Models\clsBd;
use App\Models\clsUtil;
use Yajra\Datatables\Datatables;

class BillsController extends AppBaseController {

    /** @var  BillsRepository */
    private $billsRepository;
    private $peopleRepository;
    protected $bd;
    protected $model;
    protected $util;
    protected $actions;

    public function __construct(BillsRepository $billsRepo,PeopleRepository $peopleRepo,clsBd $bd, clsUtil $obj_util, Bills $model) 
    {
        $this->billsRepository = $billsRepo;
        $this->peopleRepository = $peopleRepo;
        $this->bd = $bd;
        $this->model = $model;
        $this->util = $obj_util;
        
    }

    
    /**
     * Display a listing of the SpecialRates.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request) {
       $bills= array();
       
        if ($request->ajax()) 
        {
           
             $data_in=$request->input();
             
            $arrData['table']=$this->model->table.' AS B';
            $arrData['fillable'] = array('B.id','B.kwh','B.status_bill_id','B.bill_value','B.payment_date','B.bill_value','B.created_at','BS.name_status_bill');
            $arrData['join']=[                
                    ['table'=>'settings.people AS P','fieldA'=>'B.person_id','fieldB'=>'P.id'],
                    ['table'=>'settings.status_bill AS BS','fieldA'=>'B.status_bill_id','fieldB'=>'BS.id'],
                 ];
            
            $arrData['fillableCon'] = [['"P"."first_name",|| ||,"P"."second_name",|| ||,"P"."first_last_name",|| ||,"P"."second_last_name"', 'name']];

            $bills = $this->bd->consult($arrData);
            $postsDataTable = Datatables::of($bills)
                    ->filter(function ($query) use ($data_in) {
                        
                        if (isset($data_in['txtNroConsult']) && !empty($data_in['txtNroConsult'])) {
                            $query->where('B.id', '=',$data_in['txtNroConsult']);
                        }
                        
                        if(isset($data_in['txtDateSinceConsult']) && !empty($data_in['txtDateSinceConsult'])) {
                            $query->where('B.created_at', '>=', $data_in['txtDateSinceConsult'].' 00:00:00');
                       }
                       
                       if(isset($data_in['txtDateUntilConsult']) && !empty($data_in['txtDateUntilConsult'])) {
                            $query->where('B.created_at', '<=', $data_in['txtDateUntilConsult'].' 23:59:59');
                       }
                       
                       if(isset($data_in['TBUStxtPersonConsult']) && !empty($data_in['TBUStxtPersonConsult'])&&isset($data_in['txtPersonConsult']) && !empty($data_in['txtPersonConsult'])) {
                                $query->where('B.person_id', '=',$data_in['txtPersonConsult']);
                          } 
                        
                        
                         $query->where('B.register_status_id', '=','1');
                       $query->orderBy('B.id');
                    })->addColumn('buttons', function ($bills) 
            {
                $arr_resp_button['del_bill']=($bills->status_bill_id==1)?true:false;
                $arr_resp_button['mod_bill']=true;
                return base64_encode(json_encode($arr_resp_button));
            });

            return $postsDataTable->make(true);
        }
       
    }

    /**
     * Show the form for creating a new Bills.
     *
     * @return Response
     */
    public function create() {
     $arr_bills_status = ['0'=>'..Seleccione uno..'] + StatusBill::orderBy('name_status_bill')->pluck('name_status_bill', 'id')->all(); 

     return response()->json([
                       
                        'arr_bills_status' =>  $arr_bills_status,


            ]);
    }

    /**
     * Store a newly created Bills in storage.
     *
     * @param CreateBillsRequest $request
     *
     * @return Response
     */
    public function store(CreateBillsRequest $request) {
        if($request->ajax()) 
        {
            
            $data = array();
            
            $data['bill_value'] = $this->util->data_clean($request['txtBillValue']);
            $data['person_id'] = $this->util->data_clean($request['txtPerson']);
            $data['payment_date'] = $request['txtPaymentDate'];
            $data['kwh'] = $request['txtKwhValue'];

            $id = $this->billsRepository->create($data)->id;
            if($id)
            {
                          
                return response()->json(['status' => 'success','content' => ['message' => 'Registro creado']]);
            }
            else
            {
                return response()->json(['status' => 'error','content' => ['message' => 'Error al crear']]);
            }
        }
    }

    /**
     * Display the specified Bills.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id) {
    }

    /**
     * Show the form for editing the specified Bills.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id) {
        
  
   
        $bills = $this->billsRepository->findWithoutFail($id);
       
        $arr_response = array();

        if(!empty($bills))
        {
            $people = $this->peopleRepository->findWithoutFail($bills->person_id);
            
            $arr_response['txtPaymentDate'] = substr($bills->payment_date,0,10); 
            $arr_response['txtBillValue'] = $bills->bill_value; 
            $arr_response['txtPerson'] = $bills->person_id; 
            $arr_response['txtKwhValue'] = $bills->kwh; 
            $arr_response['TBUStxtPerson'] = $people->identification_number.' - '.$people->first_name.' '.$people->second_name.' '.$people->first_last_name.' '.$people->second_last_name; 

          }

        return response()->json($arr_response);
        
        
        
    }

    /**
     * Update the specified Bills in storage.
     *
     * @param  int              $id
     * @param UpdateBillsRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateBillsRequest $request) {

         if($request->ajax()) 
         {
            $data = array();
            
            $data['bill_value'] = $this->util->data_clean($request['txtBillValue']);
            $data['person_id'] = $this->util->data_clean($request['txtPerson']);
            $data['payment_date'] = $request['txtPaymentDate'];
             $data['kwh'] = $request['txtKwhValue'];
                
            $this->billsRepository->update($data, $id);
            return response()->json(['message' => 'listo']);
        }
    }

    /**
     * Remove the specified Bills from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $data = array();
        $data['register_status_id'] =2;
        $data['updated_at'] =  $this->util->now_date();
        $this->billsRepository->update($data, $id);
        return response()->json(['message' => 'eliminado']);

    }
     
  

}
 
