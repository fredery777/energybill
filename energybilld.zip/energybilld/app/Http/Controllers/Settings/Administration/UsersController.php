<?php

namespace App\Http\Controllers\Settings\Administration;
use App\Http\Requests\Settings\Administration\Users\CreateUsersRequest;
use App\Http\Requests\Settings\Administration\Users\UpdateUsersRequest;
use App\Repositories\Settings\Administration\UsersRepository;
use App\Http\Controllers\Controller as AppBaseController;
use Illuminate\Http\Request;
use Response;
use App\Models\Settings\Administration\Users;
use App\Models\clsBd;
use App\Models\clsUtil;
use Yajra\Datatables\Datatables;
use App\Exports\Settings\Administration\Users\UsersExport;

class UsersController extends AppBaseController {

    /** @var  UsersRepository */
    private $usersRepository;
    protected $bd;
    protected $model;
    protected $util;

    /**
     * 
     * @param UsersRepository $usersRepo
     * @param clsBd $bd
     * @param \App\Http\Controllers\Settings\Administration\clsUtil $objUtil
     * @param Users $model
     */
    public function __construct(UsersRepository $usersRepo, clsBd $bd, clsUtil $objUtil, Users $model) 
    {
        $this->usersRepository = $usersRepo;
        $this->bd = $bd;
        $this->model = $model;
        $this->util = $objUtil;

           
    }
    /**
     * Display a listing of the SpecialRates.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request) {
       $users= array();
        if ($request->ajax()) 
        {
             $data_in=$request->input();
             
            $arrData['table']=$this->model->table.' AS U';
            $arrData['fillable'] = array('U.id','U.firstname','U.email','U.lastname','U.created_at');
            $users = $this->bd->consult($arrData);

            $postsDataTable = Datatables::of($users)
                    ->filter(function ($query) use ($data_in) {
                        if (isset($data_in['txtUserCodConsult']) && !empty($data_in['txtUserCodConsult'])) {
                            $query->where('U.id', '=', $this->util->data_clean($data_in['txtUserCodConsult']));
                        }
                        if (isset($data_in['txtUserMailConsult']) && !empty($data_in['txtUserMailConsult'])) {
                            $query->where('U.email', 'like', '%' .strtoupper($this->util->data_clean($data_in['txtUserMailConsult'])) . '%');
                        }
                        
                        if (isset($data_in['txtUserNameConsult']) && !empty($data_in['txtUserNameConsult'])) {
                            $query->where('U.firstname', 'like', '%' .strtoupper($this->util->data_clean($data_in['txtUserNameConsult'])) . '%');
                        }
                        
                         if (isset($data_in['txtUserSurnameConsult']) && !empty($data_in['txtUserSurnameConsult'])) {
                            $query->where('U.lastname', 'like', '%' .strtoupper($this->util->data_clean($data_in['txtUserSurnameConsult'])) . '%');
                        }
                       $query->orderBy('U.created_at');
                    });

            return $postsDataTable->make(true);
        }
       
    }

    /**
     * Show the form for creating a new Users.
     *
     * @return Response
     */
    public function create() {}

    /**
     * Store a newly created Users in storage.
     *
     * @param CreateUsersRequest $request
     *
     * @return Response
     */
    public function store(CreateUsersRequest $request) {
        if($request->ajax()) 
        {
            $data = array();
            $data['firstname'] = strtoupper(trim($request['txtUserName']));
            $data['lastname'] = strtoupper(trim($request['txtUserSurname']));
            $data['email']=strtolower(trim($request['txtUserEmail']));
            
            //Validate if exist email
            $arr_filter[] = "email='{$data['email']}'";
            $arrData['filter']=$arr_filter;
            $arrData['table'] = 'users';
            $exist = $this->bd->check_records($arrData);
            if($exist>0)
            {
              return response()->json(['status' => 'error', 'content' =>'the email is already registered']);
            }
            $id = $this->usersRepository->create($data)->id;
            if($id)
            {
                return response()->json(['status' => 'success','content' => ['message' => 'Record Created']]);
            }
            else
            {
                return response()->json(['status' => 'error','content' => 'Error']);
            }
        }
    }

    /**
     * Display the specified Users.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id) {
    }

    /**
     * Show the form for editing the specified Users.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id) {
        
        $users = $this->usersRepository->findWithoutFail($id);
        $arr_response = array();

        if(!empty($users))
        {
          
            $arr_response['txtUserName'] = $users->firstname; 
            $arr_response['txtUserSurname'] = $users->lastname; 
            $arr_response['txtUserEmail'] = $users->email; 
        }

        return response()->json($arr_response);
        
    }

    /**
     * Update the specified Users in storage.
     *
     * @param  int              $id
     * @param UpdateUsersRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateUsersRequest $request) {

         if($request->ajax()) 
         {
            
            $data = array();
            $data['firstname'] = strtoupper(trim($request['txtUserName']));
            $data['lastname'] = strtoupper(trim($request['txtUserSurname']));
            $data['email']=strtolower(trim($request['txtUserEmail']));
            
             //Validate if exist email
            $arr_filter[] = "email='{$data['email']}' AND id<>$id";
            $arrData['filter']=$arr_filter;
            $arrData['table'] = 'users';
            $exist = $this->bd->check_records($arrData);
            if($exist>0)
            {
              return response()->json(['status' => 'error', 'content' =>'the email is already registered']);
            }
            
            $this->usersRepository->update($data, $id);
            return response()->json(['message' => 'ready']);
        }
    }

    /**
     * Remove the specified Users from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $this->usersRepository->delete($id);
        return response()->json(['message' => 'deleted']);
    }
    
    public function export_excel(Request $request) 
    {
       $data_in=$request->input();
       $arr_filter=array();  
        
       
       if(isset($data_in['txtUserCodConsult']) && !empty($data_in['txtUserCodConsult'])) {        
            $arr_filter[] = ' `U`.`id`=' .  $this->util->data_clean($data_in['txtUserCodConsult']);
       }
        if (isset($data_in['txtUserMailConsult']) && !empty($data_in['txtUserMailConsult'])) {
            $arr_filter[] = ' `U`.`email` like ' .  $this->util->str_wrap($this->util->str_wrap(strtoupper($this->util->data_clean($data_in['txtUserMailConsult'])), "%")); 
        }
        if (isset($data_in['txtUserNameConsult']) && !empty($data_in['txtUserNameConsult'])) {
            $arr_filter[] = ' `U`.`firstname` like ' .  $this->util->str_wrap($this->util->str_wrap(strtoupper($this->util->data_clean($data_in['txtUserNameConsult'])), "%")); 
        }
        if (isset($data_in['txtUserSurnameConsult']) && !empty($data_in['txtUserSurnameConsult'])) {
            $arr_filter[] = ' `U`.`lastname` like ' .  $this->util->str_wrap($this->util->str_wrap(strtoupper($this->util->data_clean($data_in['txtUserSurnameConsult'])), "%")); 
        }
        
   
       
       return (new UsersExport($arr_filter))->download('rep_users_'.$this->util->now_date().'.xls');
    }
  
}
