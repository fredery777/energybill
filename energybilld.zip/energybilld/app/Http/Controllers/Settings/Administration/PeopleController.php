<?php

namespace App\Http\Controllers\Settings\Administration;
use App\Http\Requests\Settings\Administration\People\CreatePeopleRequest;
use App\Http\Requests\Settings\Administration\People\UpdatePeopleRequest;
use App\Repositories\Settings\Administration\PeopleRepository;
use App\Http\Controllers\Controller as AppBaseController;
use Illuminate\Http\Request;
use Response;
use App\Models\Settings\Administration\People;
use App\Models\Settings\Administration\PeopleTypes;
use App\Models\Settings\Administration\PeopleStatus;
use App\Models\Settings\Administration\IdentificationsTypes;
use App\Models\Settings\Administration\PeopleGenders;

use App\Models\clsBd;
use App\Models\clsUtil;
use Yajra\Datatables\Datatables;

class PeopleController extends AppBaseController {

    /** @var  PeopleRepository */
    private $peopleRepository;
    protected $bd;
    protected $model;
    protected $util;
    protected $actions;

    public function __construct(PeopleRepository $peopleRepo,clsBd $bd, clsUtil $obj_util, People $model) 
    {
        $this->peopleRepository = $peopleRepo;
        $this->bd = $bd;
        $this->model = $model;
        $this->util = $obj_util;
        
    }

    
    /**
     * Display a listing of the SpecialRates.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request) {
       $people= array();
       
        if ($request->ajax()) 
        {
           
             $data_in=$request->input();
             
            $arrData['table']=$this->model->table.' AS P';
            $arrData['fillable'] = array('P.id','P.person_status_id','P.identification_number','P.verification_digit', 'IT.identification_type_name', 'PT.person_type_name','P.address','PS.person_status_name');
            $arrData['join']=[                
                    ['table'=>'settings.identifications_types AS IT','fieldA'=>'P.identification_type_id','fieldB'=>'IT.id'],
                    ['table'=>'settings.people_types AS PT','fieldA'=>'P.person_type_id','fieldB'=>'PT.id'],
                    ['table'=>'settings.people_status AS PS','fieldA'=>'P.person_status_id','fieldB'=>'PS.id'],
                 ];
            
            $arrData['fillableCon'] = [['"P"."first_name",|| ||,"P"."second_name",|| ||,"P"."first_last_name",|| ||,"P"."second_last_name"', 'name']];

            $people = $this->bd->consult($arrData);
            $postsDataTable = Datatables::of($people)
                    ->filter(function ($query) use ($data_in) {
                        if (isset($data_in['txtFirstNameConsult']) && !empty($data_in['txtFirstNameConsult'])) {
                            $query->where('P.first_name', 'like', '%' .strtoupper($this->util->data_clean($data_in['txtFirstNameConsult'])) . '%');
                        }
                        if (isset($data_in['txtSecondNameConsult']) && !empty($data_in['txtSecondNameConsult'])) {
                            $query->where('P.second_name', 'like', '%' .strtoupper($this->util->data_clean($data_in['txtSecondNameConsult'])) . '%');
                        }
                       
                        if (isset($data_in['txtFirstLastNameConsult']) && !empty($data_in['txtFirstLastNameConsult'])) {
                            $query->where('P.first_last_name', 'like', '%' .strtoupper($this->util->data_clean($data_in['txtFirstLastNameConsult'])) . '%');
                        }
                        if (isset($data_in['txtIdentificationNumberConsult']) && !empty($data_in['txtIdentificationNumberConsult'])) {
                            $query->where('P.identification_number', 'like', '%' .strtoupper($this->util->data_clean($data_in['txtIdentificationNumberConsult'])) . '%');
                        }
                        
                        if (isset($data_in['txtSecondLastNameConsult']) && !empty($data_in['txtSecondLastNameConsult'])) {
                            $query->where('P.second_last_name', 'like', '%' .strtoupper($this->util->data_clean($data_in['txtSecondLastNameConsult'])) . '%');
                        }
                        if (isset($data_in['optPersonTypeConsult']) && !empty($data_in['optPersonTypeConsult'])) {
                            $query->where('P.person_type_id', '=',$data_in['optPersonTypeConsult']);
                        }
                        if(isset($data_in['optPersonStatusConsult']) && !empty($data_in['optPersonStatusConsult'])) {
                            $query->where('P.person_status_id', '=',$data_in['optPersonStatusConsult']);
                        }
                        
                        if(isset($data_in['optIdentificationTypeConsult']) && !empty($data_in['optIdentificationTypeConsult'])) {
                            $query->where('P.identification_type_id', '=',$data_in['optIdentificationTypeConsult']);
                        }
                         $query->where('P.register_status_id', '=','1');
                       $query->orderBy('P.first_name');
                    })->addColumn('buttons', function ($people) 
            {
                $arr_resp_button['del_person']=true;
                $arr_resp_button['mod_person']=true;
                $arr_resp_button['row_lock']=true;
                $arr_resp_button['verified']=true;
                $arr_resp_button['verified_person']=true;
                $arr_resp_button['person_status_id']=$people->person_status_id;
                return base64_encode(json_encode($arr_resp_button));
            });

            return $postsDataTable->make(true);
        }
       
    }

    /**
     * Show the form for creating a new People.
     *
     * @return Response
     */
    public function create() {
     $arr_people_types = ['0'=>'..Seleccione uno..'] + PeopleTypes::orderBy('person_type_name')->pluck('person_type_name', 'id')->all(); 
     $arr_people_status = ['0'=>'..Seleccione uno..'] + PeopleStatus::orderBy('person_status_name')->pluck('person_status_name', 'id')->all(); 

     $arr_identifications_types = ['0'=>'..Seleccione uno..'] + IdentificationsTypes::orderBy('identification_type_name')->pluck('identification_type_name', 'id')->all(); 
     $arr_peoples_genders = ['0'=>'..Seleccione uno..'] + PeopleGenders::orderBy('gender_name')->pluck('gender_name', 'id')->all(); 

     return response()->json([
                        
                        'arr_people_types' =>  $arr_people_types,
                        'arr_peoples_genders' =>  $arr_peoples_genders,
                        'arr_people_status' =>  $arr_people_status,
                        'arr_identifications_types' =>  $arr_identifications_types,
                        'arr_actions' =>  $this->actions
            ]);
    }

    /**
     * Store a newly created People in storage.
     *
     * @param CreatePeopleRequest $request
     *
     * @return Response
     */
    public function store(CreatePeopleRequest $request) {
        if($request->ajax()) 
        {
            
            $data = array();
            
            $data['person_type_id'] = $this->util->data_clean($request['optPersonType']);
            $data['identification_type_id'] = $this->util->data_clean($request['optIdentificationType']);
            $data['identification_number'] = strtoupper($this->util->data_clean($request['txtIdentificationNumber']));
            $data['first_name'] = strtoupper($this->util->data_clean($request['txtFirstName']));
            
            if($data['person_type_id']==2)//Natural
            {
                 $data['second_name'] = (!empty($request['txtSecondName']))?strtoupper($this->util->data_clean($request['txtSecondName'])):$data['second_name']=null;
                 $data['first_last_name'] = (!empty($request['txtFirstLastName']))?strtoupper($this->util->data_clean($request['txtFirstLastName'])):$data['first_last_name']=null;
                 $data['second_last_name'] = (!empty($request['txtSecondLastName']))?strtoupper($this->util->data_clean($request['txtSecondLastName'])):$data['second_last_name']=null;
                 $data['person_gender_id'] = (!empty($request['optGender']))?$this->util->data_clean($request['optGender']):$data['person_gender_id']=null;
                 $data['verification_digit'] =null;
                         
            }
             else
             {
                $data['second_name']=null;
                $data['first_last_name']=null;
                $data['second_last_name']=null;
                $data['person_gender_id']=null;
               

             }
            
           $data['email'] = (!empty($request['txtEmail']))?strtolower(trim($request['txtEmail'])):$data['email']=null;
           $data['cell_phone'] = (!empty($request['txtCellPhone']))?$this->util->data_clean($request['txtCellPhone']):$data['cell_phone']=null;
           $data['address'] = (!empty($request['txtAddress']))?strtoupper($this->util->data_clean($request['txtAddress'])):$data['address']=null;
        
            $id = $this->peopleRepository->create($data)->id;
            if($id)
            {
                          
                return response()->json(['status' => 'success','content' => ['message' => 'Registro creado']]);
            }
            else
            {
                return response()->json(['status' => 'error','content' => ['message' => 'Error al crear']]);
            }
        }
    }

    /**
     * Display the specified People.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id) {
    }

    /**
     * Show the form for editing the specified People.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id) {
        
  
   
        $people = $this->peopleRepository->findWithoutFail($id);
        $arr_response = array();

        if(!empty($people))
        {
            //first the data select is loaded
            $arr_response['optPersonType|data-selected'] = $people->identification_type_id; 
                 //other
            $arr_response['optPersonType'] = $people->person_type_id; 
            $arr_response['txtIdentificationNumber'] = $people->identification_number; 
            $arr_response['txtFirstName'] = $people->first_name; 
            $arr_response['txtSecondName'] = $people->second_name; 
            $arr_response['txtFirstLastName'] = $people->first_last_name; 
            $arr_response['txtSecondLastName'] = $people->second_last_name; 
            $arr_response['optGender'] = $people->person_gender_id; 
            $arr_response['txtEmail'] = $people->email; 
            $arr_response['txtCellPhone'] = $people->cell_phone; 
            $arr_response['txtAddress'] = $people->address; 
            $arr_response['dvVerificationDigit'] =$people->verification_digit; 
          }

        return response()->json($arr_response);
        
        
        
    }

    /**
     * Update the specified People in storage.
     *
     * @param  int              $id
     * @param UpdatePeopleRequest $request
     *
     * @return Response
     */
    public function update($id, UpdatePeopleRequest $request) {

         if($request->ajax()) 
         {
            $data = array();
            
            $data['person_type_id'] = $this->util->data_clean($request['optPersonType']);
            $data['identification_type_id'] = $this->util->data_clean($request['optIdentificationType']);
            $data['identification_number'] = strtoupper($this->util->data_clean($request['txtIdentificationNumber']));
            $data['first_name'] = strtoupper($this->util->data_clean($request['txtFirstName']));
            
            if($data['person_type_id']==2)//Natural
            {
                 $data['second_name'] = (!empty($request['txtSecondName']))?strtoupper($this->util->data_clean($request['txtSecondName'])):$data['second_name']=null;
                 $data['first_last_name'] = (!empty($request['txtFirstLastName']))?strtoupper($this->util->data_clean($request['txtFirstLastName'])):$data['first_last_name']=null;
                 $data['second_last_name'] = (!empty($request['txtSecondLastName']))?strtoupper($this->util->data_clean($request['txtSecondLastName'])):$data['second_last_name']=null;
                 $data['person_gender_id'] = (!empty($request['optGender']))?$this->util->data_clean($request['optGender']):$data['person_gender_id']=null;
                 $data['identification_issued_date'] = (!empty($request['txtIdentificationIssuedDate']))?$this->util->data_clean($request['txtIdentificationIssuedDate']):$data['identification_issued_date']=null; 
                 $data['verification_digit'] =null;
               
            }
             else
             {
                $data['second_name']=null;
                $data['first_last_name']=null;
                $data['second_last_name']=null;
                $data['person_gender_id']=null;
                
             }
            
           $data['email'] = (!empty($request['txtEmail']))?strtolower(trim($request['txtEmail'])):$data['email']=null;
           $data['cell_phone'] = (!empty($request['txtCellPhone']))?$this->util->data_clean($request['txtCellPhone']):$data['cell_phone']=null;
           $data['address'] = (!empty($request['txtAddress']))?strtoupper($this->util->data_clean($request['txtAddress'])):$data['address']=null;
           $data['updated_at'] =  $this->util->now_date();

            $arrData = [
                 'name' => 'settings.pl_store_rol_person',
                 'param' => [json_encode(array('created_user_id'=>auth()->user()->id,'person_id'=>$id,'data_rol'=>$request['txtHdDataRolPerson']))]
             ];

            $this->bd->execute_procedure($arrData);
                
            $this->peopleRepository->update($data, $id);
            return response()->json(['message' => 'listo']);
        }
    }

    /**
     * Remove the specified People from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $data = array();
        $data['register_status_id'] =2;
        $data['updated_at'] =  $this->util->now_date();
        $this->peopleRepository->update($data, $id);
        return response()->json(['message' => 'eliminado']);

    }
     

public function mod_person(Request $request)
{
        $arr_data=$request->input();
        $data = array();
        $data['updated_at'] =  $this->util->now_date();
        $data_mod = array_merge($data, $arr_data);
        
        $this->peopleRepository->update($data_mod, $arr_data['id']);
        return response()->json(['message' => 'Actualizado']);

  }
  

}
 
