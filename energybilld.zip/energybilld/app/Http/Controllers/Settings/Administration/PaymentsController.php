<?php

namespace App\Http\Controllers\Settings\Administration;
use App\Http\Requests\Settings\Administration\Payments\CreatePaymentsRequest;
use App\Http\Requests\Settings\Administration\Payments\UpdatePaymentsRequest;
use App\Repositories\Settings\Administration\PaymentsRepository;
use App\Repositories\Settings\Administration\BillsRepository;
use App\Http\Controllers\Controller as AppBaseController;
use Illuminate\Http\Request;
use Response;
use App\Models\Settings\Administration\Payments;
use App\Models\Settings\Administration\StatusBill;

use App\Models\clsBd;
use App\Models\clsUtil;
use Yajra\Datatables\Datatables;

class PaymentsController extends AppBaseController {

    /** @var  PaymentsRepository */
    private $paymentsRepository;
    private $billsRepository;
    protected $bd;
    protected $model;
    protected $util;
    protected $actions;

    public function __construct(PaymentsRepository $paymentsRepo,BillsRepository $billsRepo,clsBd $bd, clsUtil $obj_util, Payments $model) 
    {
        $this->paymentsRepository = $paymentsRepo;
        $this->billsRepository = $billsRepo;
        $this->bd = $bd;
        $this->model = $model;
        $this->util = $obj_util;
        
    }

    
    /**
     * Display a listing of the SpecialRates.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request) {
       $payments= array();
       
        if ($request->ajax()) 
        {
           
             $data_in=$request->input();
             
            $arrData['table']=$this->model->table.' AS PA';
            $arrData['fillable'] = array('PA.id','B.id AS bill_num','B.bill_value','PA.created_at');
            $arrData['join']=[                
                    ['table'=>'settings.bills AS B','fieldA'=>'PA.bill_id','fieldB'=>'B.id'],
                    ['table'=>'settings.people AS P','fieldA'=>'B.person_id','fieldB'=>'P.id'],
                    ['table'=>'settings.status_bill AS BS','fieldA'=>'B.status_bill_id','fieldB'=>'BS.id'],
                 ];
            
            $arrData['fillableCon'] = [['"P"."first_name",|| ||,"P"."second_name",|| ||,"P"."first_last_name",|| ||,"P"."second_last_name"', 'name']];

            $payments = $this->bd->consult($arrData);
            $postsDataTable = Datatables::of($payments)
                    ->filter(function ($query) use ($data_in) {
                        
                        if (isset($data_in['txtNroConsult']) && !empty($data_in['txtNroConsult'])) {
                            $query->where('PA.id', '=',$data_in['txtNroConsult']);
                        }
                        
                        if(isset($data_in['TBUStxtBillConsult']) && !empty($data_in['TBUStxtBillConsult'])&&isset($data_in['txtBillConsult']) && !empty($data_in['txtBillConsult'])) {
                                $query->where('B.id', '=',$data_in['txtBillConsult']);
                          } 
                        
                        if(isset($data_in['txtDateSinceConsult']) && !empty($data_in['txtDateSinceConsult'])) {
                            $query->where('PA.created_at', '>=', $data_in['txtDateSinceConsult'].' 00:00:00');
                       }
                       
                       if(isset($data_in['txtDateUntilConsult']) && !empty($data_in['txtDateUntilConsult'])) {
                            $query->where('PA.created_at', '<=', $data_in['txtDateSinceConsult'].' 23:59:59');
                       }
                       
                       if(isset($data_in['TBUStxtPersonConsult']) && !empty($data_in['TBUStxtPersonConsult'])&&isset($data_in['txtPersonConsult']) && !empty($data_in['txtPersonConsult'])) {
                                $query->where('B.person_id', '=',$data_in['txtPersonConsult']);
                          } 
                        
                        
                         $query->where('PA.register_status_id', '=','1');
                       $query->orderBy('PA.id');
                    })->addColumn('buttons', function ($payments) 
            {
                $arr_resp_button['mod_bill']=true;
                return base64_encode(json_encode($arr_resp_button));
            });

            return $postsDataTable->make(true);
        }
       
    }

    /**
     * Show the form for creating a new Payments.
     *
     * @return Response
     */
    public function create() {
     $arr_payments_status = ['0'=>'..Seleccione uno..'] + StatusBill::orderBy('name_status_bill')->pluck('name_status_bill', 'id')->all(); 

     return response()->json([
                       
                        'arr_payments_status' =>  $arr_payments_status,


            ]);
    }

    /**
     * Store a newly created Payments in storage.
     *
     * @param CreatePaymentsRequest $request
     *
     * @return Response
     */
    public function store(CreatePaymentsRequest $request) {
        if($request->ajax()) 
        {
            
            $data = array();
            
            $data['bill_id'] = $this->util->data_clean($request['txtBillNum']);
           
            $id = $this->paymentsRepository->create($data)->id;
            if($id)
            {
                          
                return response()->json(['status' => 'success','content' => ['message' => 'Registro creado']]);
            }
            else
            {
                return response()->json(['status' => 'error','content' => ['message' => 'Error al crear']]);
            }
        }
    }

    /**
     * Display the specified Payments.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id) {
    }

    /**
     * Show the form for editing the specified Payments.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id) {
        
  
   
        $payments = $this->paymentsRepository->findWithoutFail($id);
       
        $arr_response = array();

        if(!empty($payments))
        {

            $arr_response['TBUStxtBillNum'] = $payments->bill_id; 
            $arr_response['txtBillNum'] = $payments->bill_id; 
          }

        return response()->json($arr_response);
        
        
        
    }

    /**
     * Update the specified Payments in storage.
     *
     * @param  int              $id
     * @param UpdatePaymentsRequest $request
     *
     * @return Response
     */
    public function update($id, UpdatePaymentsRequest $request) {

         if($request->ajax()) 
         {
            $data = array();
            
            $data['bill_id'] = $this->util->data_clean($request['txtBillNum']);
                
            $this->paymentsRepository->update($data, $id);
            return response()->json(['message' => 'listo']);
        }
    }

    /**
     * Remove the specified Payments from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $data = array();
        $data['register_status_id'] =2;
        $data['updated_at'] =  $this->util->now_date();
        $this->paymentsRepository->update($data, $id);
        return response()->json(['message' => 'eliminado']);

    }
     
  

}
 
