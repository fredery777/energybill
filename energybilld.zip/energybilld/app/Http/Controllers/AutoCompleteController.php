<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller as AppBaseController;
use Response;
use App\Models\clsBd;
use Illuminate\Http\Request;

class AutoCompleteController extends AppBaseController
{
    protected $bd;
    
    function __construct(clsBd $bd)
    {
        $this->bd     = $bd;
    }
    
    public function auto_complete(Request $request)
    {
        $arr_get = $request->input();

        if($arr_get['general'])
        {
            $route = 'App\Models\\'.$arr_get['route'].'\\'.$arr_get['model'];
            $model = new $route;
           
	    $method=$arr_get['method'];

            $arr_fields_model = $model->$method($arr_get['term']);
            
            $arrData['table']=(isset($arr_fields_model['table']))?$arr_fields_model['table']:$model->table;
            if(isset($arr_fields_model['join']))
            {
                 $arrData['join']=$arr_fields_model['join'];
            }
            if(!empty($arr_get['where']))
            {
                
                if(!is_array($arr_get['where']))
                {
                    $arr_get['where'] = json_decode($arr_get['where'],true);
                }
               
                array_push($arr_fields_model['filter'], $arr_get['where']);

            }
            $arrData['filter'] = $arr_fields_model['filter'];
            $arrData['fillable']=$arr_fields_model['fillable'];
            $arrData['orderBy']=(isset($arr_fields_model['orderBy']) ? $arr_fields_model['orderBy']  : (!empty($model->primaryKey) ? [['field'=>$model->primaryKey]] : [['field'=>'id']]) );
        }else{
            $arrData['table']=\Input::get('table');

            $arrData['filter'] = $arr_get['where'];
            $arrData['fillable']=$arr_get['fillable'];
        }
        $arrData['get']= true;
       // $arrData['toSql']=true;
      
        $arr_data = $this->bd->consult($arrData);

        $results = array();
        if(count($arr_data)>0)
        {
             
            foreach ($arr_data as $query)
            {
                $value ='';
                for($i = 0; $i < count($arrData['fillable']); $i++)
                {
		    $fillable=$arrData['fillable'][$i];
                    
                    if(isset($query->$fillable))
                        $value .= ($i == 0 ? $query->$fillable : ($i == 1 ? ' - '.$query->$fillable: ' '.$query->$fillable));
                }
                $results[] = [ 'id' => $query->id_label, 'value' => $value];
            }
        }
        else{
            $results[] = [ 'id' => '', 'value' => 'No se encontraron Registros' ];
        }

        return Response::json($results);
    }
}
