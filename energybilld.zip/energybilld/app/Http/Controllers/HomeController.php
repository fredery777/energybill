<?php
namespace App\Http\Controllers;
use App\Models\clsUtil;
class HomeController extends Controller
{
   public function __construct(clsUtil $util)
    {
        $this->middleware('auth');
         $this->util     = $util;
    }

    public function index() {
      // return view('home.module-home');
       
       $arrPar=array();
       $arr_module_ppal = $this->util->allowed_module($arrPar); 
		
    	$cant_modules=(isset($arr_module_ppal[0]->count)&&!empty($arr_module_ppal[0]->count))?$arr_module_ppal[0]->count:0;
	$json_data=  json_encode(array('data_module'=>$arr_module_ppal,'cant'=>$cant_modules));
    	return view('modules',compact('arr_module_ppal','json_data'));
       
       
    }
    
      public function template($name_template) 
    {
        
        return view('home.module-home', compact('name_template'));
    }
    
    
     public function module()
     {
         return response()->json(['id'=>1]);
     }

}
