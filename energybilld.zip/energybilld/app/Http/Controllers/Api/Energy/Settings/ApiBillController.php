<?php

namespace App\Http\Controllers\Api\Energy\Settings;
use App\Http\Controllers\Api\ApiBaseController as BaseController;
use Illuminate\Http\Request;
use App\Models\clsBd;
use App\Models\clsUtil;


class ApiBillController extends BaseController {

   
    protected $bd;
    protected $util;
    protected $model;

    public function __construct(clsBd $bd, clsUtil $obj_util) 
    {
        $this->bd = $bd;
        $this->util = $obj_util;
       
    }

    function get_bill_report(Request $request)
    {
            $data_in=$request->input();
            
            $arrData['table']='settings.bills AS B';
            $arrData['fillable'] = array('B.id AS bill_num','B.status_bill_id','B.bill_value','B.payment_date','B.bill_value','B.created_at','BS.name_status_bill');
            $arrData['join']=[                
                    ['table'=>'settings.people AS P','fieldA'=>'B.person_id','fieldB'=>'P.id'],
                    ['table'=>'settings.status_bill AS BS','fieldA'=>'B.status_bill_id','fieldB'=>'BS.id'],
                 ];
            
            $arrData['fillableCon'] = [['"P"."first_name",|| ||,"P"."second_name",|| ||,"P"."first_last_name",|| ||,"P"."second_last_name"', 'name']];
           
         $arr_filter=array();  
        
     
       if(isset($data_in['date_since']) && !empty($data_in['date_since'])) {        
           $arr_filter[] = ' "B"."created_at" >= ' .  $this->util->str_wrap($this->util->data_clean($data_in['date_since'].' 00:00:00'));

       }
       if(isset($data_in['date_until']) && !empty($data_in['date_until'])) {        
           $arr_filter[] = ' "B"."created_at" <= ' .  $this->util->str_wrap($this->util->data_clean($data_in['date_until'].' 23:59:59'));

       }

        $arr_filter[] = '"B"."register_status_id"=1';
      
             $arrData['filter'] = $arr_filter;
             //print_r($arr_filter);exit;
            $arrData['get']= true;
            $arr_data =  $this->bd->consult($arrData);
            if(count($arr_data)>0)
            {
                 return $this->sendResponse($arr_data, 'successfully.');
            }
            else
            {
                  return $this->sendError('No hay datos');
            }
    
    }
    
    
    function get_payment_report(Request $request)
    {
            $data_in=$request->input();
            
             $arrData['table']='settings.payments AS PA';
            $arrData['fillable'] = array('PA.id AS pay_number','B.id AS bill_num','B.bill_value','PA.created_at');
            $arrData['join']=[                
                    ['table'=>'settings.bills AS B','fieldA'=>'PA.bill_id','fieldB'=>'B.id'],
                    ['table'=>'settings.people AS P','fieldA'=>'B.person_id','fieldB'=>'P.id'],
                    ['table'=>'settings.status_bill AS BS','fieldA'=>'B.status_bill_id','fieldB'=>'BS.id'],
                 ];
            
            $arrData['fillableCon'] = [['"P"."first_name",|| ||,"P"."second_name",|| ||,"P"."first_last_name",|| ||,"P"."second_last_name"', 'name']];
           
         $arr_filter=array();  
        
     
       if(isset($data_in['date_since']) && !empty($data_in['date_since'])) {        
           $arr_filter[] = ' "PA"."created_at" >= ' .  $this->util->str_wrap($this->util->data_clean($data_in['date_since'].' 00:00:00'));

       }
       if(isset($data_in['date_until']) && !empty($data_in['date_until'])) {        
           $arr_filter[] = ' "PA"."created_at" <= ' .  $this->util->str_wrap($this->util->data_clean($data_in['date_until'].' 23:59:59'));

       }

        $arr_filter[] = '"PA"."register_status_id"=1';
      
             $arrData['filter'] = $arr_filter;
             //print_r($arr_filter);exit;
            $arrData['get']= true;
            $arr_data =  $this->bd->consult($arrData);
            if(count($arr_data)>0)
            {
                 return $this->sendResponse($arr_data, 'successfully.');
            }
            else
            {
                  return $this->sendError('No hay datos');
            }
    
    }
    
    function get_history_report(Request $request)
    {
            $data_in=$request->input();
            
            $arrData['table']='settings.bills AS B';
            $arrData['fillable'] = array('B.id AS bill_num','B.kwh','B.created_at');
            $arrData['join']=[                
                    ['table'=>'settings.people AS P','fieldA'=>'B.person_id','fieldB'=>'P.id'],
                 ];
            
            $arrData['fillableCon'] = [['"P"."first_name",|| ||,"P"."second_name",|| ||,"P"."first_last_name",|| ||,"P"."second_last_name"', 'name']];
           
         $arr_filter=array();  
        
     
       if(isset($data_in['date_since']) && !empty($data_in['date_since'])) {        
           $arr_filter[] = ' "B"."created_at" >= ' .  $this->util->str_wrap($this->util->data_clean($data_in['date_since'].' 00:00:00'));

       }
       if(isset($data_in['date_until']) && !empty($data_in['date_until'])) {        
           $arr_filter[] = ' "B"."created_at" <= ' .  $this->util->str_wrap($this->util->data_clean($data_in['date_until'].' 23:59:59'));

       }

        $arr_filter[] = '"B"."register_status_id"=1';
      
             $arrData['filter'] = $arr_filter;
             //print_r($arr_filter);exit;
            $arrData['get']= true;
            $arr_data =  $this->bd->consult($arrData);
            if(count($arr_data)>0)
            {
                 return $this->sendResponse($arr_data, 'successfully.');
            }
            else
            {
                  return $this->sendError('No hay datos');
            }
    
    }
    
    
   

}
