<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller as AppBaseController;
use App\Models\clsBd;
use Illuminate\Http\Request;

class UtilController extends AppBaseController {

    protected $bd;

    function __construct(clsBd $bd) {
        $this->bd = $bd;
    }

    public function generateSelect(Request $request) 
    {
        $arr_get=$request->input();
        $results = array();
        $arrData = array();
         
        $results['select'] = $arr_get['select'];
        $selected = 0;
        $alias='';
        if (isset($arr_get['selected']) && trim($arr_get['selected'])!='')
            $selected = $arr_get['selected'];

        $results['data'][] = ['id' => '0', 'value' => '..Seleccione uno..'];
        if ($arr_get['table']) {
            $arrData['table'] = $arr_get['table'];
            
            if (isset($arr_get['alias']) && !empty($arr_get['alias']))
                $arrData['table'] =  $arrData['table'].' AS '.$arr_get['alias'];

            if (isset($arr_get['filter']) && !empty($arr_get['filter']))
                $arrData['filter'] = [$arr_get['filter']];
            
            if (isset($arr_get['join']) && !empty($arr_get['join']))
                $arrData['join'] = $arr_get['join'];
            
            if (isset($arr_get['fillableCon']) && !empty($arr_get['fillableCon']))
            {
                $arr_concat=array();
                for ($i = 0; $i < count($arr_get['fillableCon']); $i++) 
                {
                 $arrData['fillableCon'][]=[$arr_get['fillableCon'][$i]['field'], $arr_get['fillableCon'][$i]['alias']];
                 $alias=$arr_get['fillableCon'][$i]['alias'];
                }
            }

            if (isset($arr_get['fillable']) && !empty($arr_get['fillable']))
                $arrData['fillable'] = $arr_get['fillable'];
             else if (isset($arr_get['name']) && !empty($arr_get['name']))
                $arrData['fillable'] = [$arr_get['id'], $arr_get['name']];
             else
                   $arrData['fillable'] = [$arr_get['id']];
             
            if (isset($arr_get['orderBy']) && !empty($arr_get['orderBy']))
                $arrData['orderBy'] = [['field' => $arr_get['orderBy']]];

            $arrData['get'] = true;
           // $arrData['toSql']=true;
          
            $arr_data = $this->bd->consult($arrData);
             //print_r($arr_data);exit;
         
            if (!empty($arr_data)) 
            {
    
                foreach ($arr_data as $result) 
               {
                    $id = (isset($arr_get['idObj']))?$arr_get['idObj']:$arr_get['id'];
                    $name = (!empty($alias))?$alias:$arr_get['name'];
                    
                    if (trim($selected)!='' && $selected == $result->$id)
                        $results['data'][] = ['id' => $result->$id, 'value' => $result->$name, 'selected' => true];
                    else
                        $results['data'][] = ['id' => $result->$id, 'value' => $result->$name];
                }
            }
        }
        return $results;
    }
    
    
    public function get_verification_digit(Request $request) 
    {
        $arr_data=$request->input();
         $arrData = [
            'name' => 'util_bd.pl_get_verification_digit',
            'param' => [$arr_data['identificationNumber']]
        ];
        $verification_digit = $this->bd->execute_procedure($arrData);
        $verification_digit=$verification_digit[0]->pl_get_verification_digit;
      return $verification_digit;
    }

}
