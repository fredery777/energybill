<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

return [
    'options' => [
        'copyright' => 'Copyright © '.date("Y").'.',
        'recommendation' => 'The use of Internet Explorer, Firefox or Google Chrome is recommended in its latest updates. '
    ]
];