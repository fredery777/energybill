<?php
/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */

Route::get('/', ['uses' => 'HomeController@index', 'as' => 'home']);
Route::post('/module',['uses' =>'HomeController@module','as' => 'module']);
Route::get('/template/{template}', ['uses' => 'HomeController@template', 'as' => 'template']);
Route::post('/template/{template}', ['uses' => 'HomeController@template', 'as' => 'template']);
 Route::post('search/autocomplete', 'AutoCompleteController@auto_complete');
 
Route::group(['prefix' => 'util'], function () {
    Route::post('generateSelect', 'UtilController@generateSelect');
    Route::post('getVerificationDigit', 'UtilController@get_verification_digit');

});
    
Route::get('logs', '\Rap2hpoutre\LaravelLogViewer\LogViewerController@index');


Route::group(['namespace' => 'Settings\Administration', 'prefix' => 'administration', 'middleware' => ['guest']], function () {
  
    Route::post('people/modPerson', 'PeopleController@mod_person');
   Route::resource('people', 'PeopleController');
   
   Route::resource('bills', 'BillsController');
   Route::resource('payments', 'PaymentsController');

});






