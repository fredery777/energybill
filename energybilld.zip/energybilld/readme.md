

# Getting started

## Installation
Run the database migrations (**Set the database connection in .env before migrating**)

php artisan migrate

Start the local development server

    php artisan serve --host 127.0.0.1 --port 8000

You can now access the server at http://localhost:8000

You can watch a demo online here https://bvstudio.fundacionunipanamericana.com

----------

# Code overview

## Folders

- `app` - Contains all the Eloquent models
- `app/Http/Controllers/Settings/Administration/UsersController.php` - Contains user  controllers
- `app/Http/Controllers/HomeController.php` - Contains home  controllers

- `app/Models/Settings/Administration/Users.php` - Contains dynamic Users model
- `app/Models/clsBd.php` - Contains dynamic sql creation
- `app/Models/clsUtil.php` - Contains dynamic functions

- `app/Http/Requests/` - Contains all form requests
- `app/Repositories/` - Contains the repositories of each model
- `app/Exports/Settings/Administration/Users/UsersExport.php` - Contains the logic of the xls
- `resources/js/components/Settings/Administration/users/dataTable.vue` - Contains the component of databla
- `resources/js/components/Settings/Administration/users/index.vue` - Contains the component of search form
- `resources/js/components/Settings/Administration/users/modals.vue` - Contains the component of modals form 
- `resources/js/components/Init.vue` - Contains the initial component
- `resources/views` - Contains the front end blade files
- `public` - Contains the js and CSS of the project
- `database/migrations` - Contains all the database migrations
- `routes` - Contains all the api routes defined in api.php file

## Environment variables

- `.env` - Environment variables can be set in this file

***Note*** : You can quickly set the database information and other variables in this file and have the application fully working.

----------

# Testing

Run the laravel development server

     php artisan serve --host 127.0.0.1 --port 8000

The api can now be accessed at

    http://localhost:8000
   You can watch a demo online here https://bvstudio.fundacionunipanamericana.com
Request headers

| **Required** 	| **Key**              	| **Value**            	|
|----------	|------------------	|------------------	|
| Yes      	| Content-Type     	| application/json 	|
| Yes      	| X-Requested-With 	| XMLHttpRequest   	|
----------